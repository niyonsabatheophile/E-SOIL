const displayMap = async (id) => {
    try {
        const res = await axios.get("https://localhost/WebApp2/api/data.php");

        var mymap = L.map(id).setView([-1.944880, 30.062380], 10);

        L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors',
                maxZoom: 18,
            }).addTo(mymap);


        for(let i in res.data) {
            L.marker([res.data[i].latitude, res.data[i].longitude]).addTo(mymap)
                .bindPopup("<b>pH value: </b><br />" + res.data[i].ph).openPopup();

            L.circle([res.data[i].latitude, res.data[i].longitude], 500, {
                color: 'red',
                fillColor: '#f03',
                fillOpacity: 0.5
            }).addTo(mymap).bindPopup(res.data[i].location);
        }
    } catch (error) {
        console.log("Map error: ", error);
    }
    
}
displayMap("mapid");