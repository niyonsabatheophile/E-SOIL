const result = (input) => {
  let ph = parseFloat(input);
  let res = [];
  if (ph >= 6.0 && ph <= 6.5) {
    res = ("Beans, Broccoli, Garlic, Lettuce");
  } else if (ph >= 6.5 && ph <= 7.5) {
    res = ("Cabbage");
  } else if (ph >= 5.8 && ph <= 6.4) {
    res = "Carrots, Tomatoes, Strawberries";
  } else {
    res = "Onions, Pineaples, Peas";
  }
  return res;
}


const chartDiagram = (id, xData, yData, type) => {
  var options = {
    chart: {
        type: type
    },
    series: [{
        name: 'pH',
        data: yData
    }],
    xaxis: {
        categories: xData
    }
  }
  
  var chart = new ApexCharts(document.querySelector(id), options);

  chart.render();
}

// const getLocation = async (latitude, longitude) => {
//     const res = await axios.get(`https://us1.locationiq.com/v1/reverse.php?key=pk.1ca8c07397ad198333b6e82e4bc1c7ab&format=json&lat=${latitude}&lon=${longitude}`);
//     console.log("Res: ", res);
// }

// getLocation("1.9500", "30.0588");

const getAllData = async () => {
  let locations = [];
  let phData = [];
  let allData = [];
    let allvalue=[];
  try {
    const res = await axios.get("https://e-soil.universalbridge.rw/api/data.php");
    for(let i in res.data) {
      allData.push([parseInt(i) + 1, res.data[i].location, res.data[i].latitude, res.data[i].longitude, res.data[i].ph, res.data[i].sensorValue,res.data[i].date_in, `<button>${result(res.data[i].ph)}</button>`]);
      if (i < 10) {
        locations.push(res.data[i].location);
        phData.push(res.data[i].ph);
      }
    }
    chartDiagram("#chart", locations, phData, "line");
    chartDiagram("#chartB", locations, phData, "bar");
    $(document).ready(function() {
      $('#data-table').DataTable( {
          buttons: {
            buttons: [ 'copy', 'csv', 'excel' ]
          },
          data: allData,
          columns: [
            { title: "#" },
            { title: "Location" },
            { title: "Latitude" },
            { title: "Lognitude" },
            { title: "pH" },
            { title: "Moisture" },
            { title: "Date recorded" },
            { title: "Result" },
          ]
      } );
    } );
  } catch (error) {
    console.log("Err: ", error);
  }
  
}
getAllData();

const displayMap = async (id) => {
  try {
      const res = await axios.get("https://e-soil.universalbridge.rw/api/data.php");

      var mymap = L.map(id).setView([-1.944880, 30.062380], 10);

      L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {
          attribution: '&copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors',
              maxZoom: 18,
          }).addTo(mymap);


      for(let i in res.data) {
          L.marker([res.data[i].latitude, res.data[i].longitude]).addTo(mymap)
              .bindPopup("<b>pH value: </b><br />" + res.data[i].ph).openPopup();

          L.circle([res.data[i].latitude, res.data[i].longitude], 500, {
              color: 'red',
              fillColor: '#f03',
              fillOpacity: 0.5
          }).addTo(mymap).bindPopup(res.data[i].location);
      }
  } catch (error) {
      console.log("Map error: ", error);
  }
  
}
displayMap("mapid");