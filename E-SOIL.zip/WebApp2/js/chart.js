const chartDiagram = (id, xData, yData, type) => {
    var options = {
      chart: {
          type: type
      },
      series: [{
          name: 'pH',
          data: yData
      }],
      xaxis: {
          categories: xData
      }
    }
    
    var chart = new ApexCharts(document.querySelector(id), options);
  
    chart.render();
}

const getAllData = async () => {
    let locations = [];
    let phData = [];
    try {
      const res = await axios.get("https://localhost/WebApp2/api/data.php");
      for(let i in res.data) {
          locations.push(res.data[i].location);
          phData.push(res.data[i].ph);
      }
      chartDiagram("#chart", locations, phData, "line");
      chartDiagram("#chartB", locations, phData, "bar");
    } catch (error) {
      console.log("Err: ", error);
    }
  }
  getAllData();