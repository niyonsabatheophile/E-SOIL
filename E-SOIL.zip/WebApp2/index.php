<?php session_start(); ?>
<?php require_once 'utils/utils.php'; ?>
<!DOCTYPE html>
<html lang="en">
<?php // Base url
function base()
{
    echo str_replace('index.php', '', $_SERVER['PHP_SELF']);
} ?>
<?php require_once 'includes/head.php'; ?>
<!-- Body part -->
<body class="animate__animated">
<?php if (isset($_SESSION['admin'])) {
    require_once 'includes/nav.php'; ?>
    <div class="row">
        <div class="col xl2 l2 m12 s12"></div>
        <div class="col xl10 l10 m12 s12">
        <?php require_once 'url_controller.php'; ?>
        </div>
    </div>
<?php
} else {
    require_once 'pages/login.php';
} ?>
    <!-- Compiled and minified JavaScript -->
    <script src="<?php base(); ?>materialize/js/materialize.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <!-- Axios file -->
    <script src="<?php base(); ?>js/axios.min.js"></script>
    <!-- Make sure you put this AFTER Leaflet's CSS -->
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"
    integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA=="
    crossorigin=""></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.22/datatables.min.js"></script>
    <?php if (isset($url[0])) {
        if ($url[0] == 'chart') { ?>
        <script src="<?php base(); ?>js/chart.js"></script>
        <?php } elseif ($url[0] == 'map') { ?>
            <script src="<?php base(); ?>js/map.js"></script>
        <?php } else { ?>
            <script src="<?php base(); ?>js/index.js"></script>
            <?php }
    } else {
         ?>
        <script src="<?php base(); ?>js/index.js"></script>
        <?php
    } ?>
</body>
</html>