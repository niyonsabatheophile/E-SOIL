<style>
    #mapid { height: 300px; }
</style>
<div class="page-card-white">
    <b><h5>Dashborad summary</h5></b>
    <hr>
    <div class="row">
        <div class="col xl6 l6 m6 s12">
            <div>
                <div>Current measures (Line chart)</div>
                <div id="chart"></div>
            </div>
        </div>
        <div class="col xl6 l6 m6 s12">
            <div>
                <div>Current measures (Bar chart)</div>
                <div id="chartB"></div>
            </div>
        </div>
    </div>
    <b><h5>Map representation</h5></b>
    <hr>
    <div class="row">
        <div class="col l12">
            <div id="mapid"></div>
        </div>
    </div>
    <b><h5>New data captured by sensor</h5></b>
    <hr>
    <div class="row">
        <div class="col l12">
            <div class="myTable" style="padding: 20px; background-color: #f1f1f1">
                <table id="data-table" class="display" width="100%">
                    
                </table>
            </div>
        </div>
    </div>
</div>