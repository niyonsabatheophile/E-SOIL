<style>
    #mapid { height: 300px; }
</style>
<div class="page-card-white">
    <b><h5>Dashborad summary</h5></b>
    <hr>
    <div class="row">
        <div class="col xl12 l12 m12 s12">
            <div>
                <div>Current measures (Line chart)</div>
                <div id="chart"></div>
            </div>
        </div>
        <div class="col xl12 l12 m12 s12">
            <div>
                <div>Current measures (Bar chart)</div>
                <div id="chartB"></div>
            </div>
        </div>
    </div>
</div>