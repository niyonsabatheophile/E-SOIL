<?php
function current_time()
{
    $currentTime = time();
    $hoursToAdd = 1;
    $secondsToAdd = $hoursToAdd * (60 * 60);
    $newTime = $currentTime + $secondsToAdd;
    return date('d/m/y H:i', $newTime);
} ?>
