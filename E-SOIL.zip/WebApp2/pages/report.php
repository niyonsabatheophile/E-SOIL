<div class="page-card-white">
    <b><h5>All data captured by sensor</h5></b>
    <hr>
    <div class="row">
        <div class="col l12">
            <div class="myTable" style="padding: 20px; background-color: #f1f1f1">
                <table id="data-table" class="display" width="100%"></table>
            </div>
        </div>
    </div>
</div>