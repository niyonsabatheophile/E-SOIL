<?php
if (isset($_POST['submit'])) {
    if (!isset($_POST['username'])) {
        echo "<script>alert('Please fill your username!')</script>";
    } elseif (!isset($_POST['password'])) {
        echo "<script>alert('Please fill your username!')</script>";
    } else {
        if (
            $_POST['username'] == 'admin@gmail.com' &&
            $_POST['password'] == 'group8'
        ) {
            $_SESSION['admin'] = 'Welcome admin';
            header('Location: /');
        }
    }
} ?>
<style>
*,
*::before,
*::after {
  padding: 0;
  margin: 0;
  box-sizing: border-box;
  list-style: none;
  list-style-type: none;
  text-decoration: none;
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  text-rendering: optimizeLegibility;
}

body {
  font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
  font-size: 1rem;
  font-weight: normal;
  line-height: 1.5;
  color: #252a32;
  background: #074e0a;
}

img {
  display: block;
  width: 100%;
  height: auto;
}

a,
button {
  font-family: inherit;
  font-size: inherit;
  line-height: inherit;
  cursor: pointer;
  border: none;
  outline: none;
  background: none;
  text-decoration: none;
}

.container {
  max-width: 85rem;
  width: 100%;
  height: auto;
  padding: 0 2rem;
  margin: 0 auto;
}

.wrapper {
  max-width: 28rem;
  width: 100%;
  margin: 0 auto;
  padding: 2rem 1.5rem;
}

.card {
  padding: 1.5rem 2rem;
  border: none;
  outline: none;
  border-radius: 4px;
  color: #252a32;
  background: #ffffff;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 3px rgba(0, 0, 0, 0.24);
}

.icons {
  font-size: 1.45rem;
  line-height: inherit;
  margin-right: 0.5rem;
  border: none;
  outline: none;
  background: none;
}
.icons-google {
  color: #d32f2f;
}
.icons-facebook {
  color: #0f698a;
}
.icons-apple {
  color: #252a32;
}

.linktext {
  font-family: inherit;
  font-size: 0.95rem;
  line-height: inherit;
  color: #148cb8;
  text-rendering: optimizeLegibility;
}
.linktext:hover {
  text-decoration: underline;
}

.title {
  font-family: inherit;
  line-height: inherit;
  text-rendering: optimizeLegibility;
}
.title-large {
  font-size: 2rem;
  font-weight: 600;
  color: #252a32;
}
.title-subs {
  font-size: 0.95rem;
  font-weight: 400;
  line-height: inherit;
}

.main .wrapper .form {
  width: 100%;
  height: auto;
  margin: 2rem 0;
}
.main .wrapper .form-group {
  display: -webkit-box;
  display: flex;
  -webkit-box-orient: horizontal;
  -webkit-box-direction: normal;
          flex-direction: row;
  -webkit-box-pack: justify;
          justify-content: space-between;
  -webkit-box-align: center;
          align-items: center;
  margin-bottom: 1rem;
}
.main .wrapper .form-group .input-field {
  font-family: inherit;
  font-size: 0.95rem;
  font-weight: 400;
  line-height: inherit;
  width: 100%;
  height: auto;
  padding: 0.75rem 1.25rem;
  border: none;
  outline: none;
  border-radius: 2rem;
  color: #252a32;
  background: #f1f5f8;
}
.main .wrapper .form-group .input-submit {
  font-family: inherit;
  font-size: 0.95rem;
  font-weight: 500;
  line-height: inherit;
  cursor: pointer;
  padding: 0.65rem 2rem;
  border: none;
  outline: none;
  border-radius: 2rem;
  text-align: center;
  color: #ffffff;
  background: #074e0a !important;
}
.main .wrapper .line {
  display: -webkit-box;
  display: flex;
  -webkit-box-orient: horizontal;
  -webkit-box-direction: normal;
          flex-direction: row;
  -webkit-box-pack: center;
          justify-content: center;
  -webkit-box-align: center;
          align-items: center;
  margin-bottom: 1rem;
}
.main .wrapper .line-bar {
  -webkit-box-flex: 1;
          flex: auto;
  flex-basis: auto;
  border: none;
  outline: none;
  height: 1.3px;
  background: #bed1df;
}
.main .wrapper .line-text {
  font-weight: 500;
  color: #252a32;
  padding: 0 1rem;
}
.main .wrapper .method-item {
  margin-bottom: 0.5rem;
}
.main .wrapper .method-item .btn-action {
  display: -webkit-box;
  display: flex;
  -webkit-box-orient: horizontal;
  -webkit-box-direction: normal;
          flex-direction: row;
  -webkit-box-pack: center;
          justify-content: center;
  -webkit-box-align: center;
          align-items: center;
  font-family: inherit;
  font-size: 0.95rem;
  font-weight: 500;
  line-height: inherit;
  padding: 0.2rem 1rem;
  width: 100%;
  height: auto;
  outline: none;
  border: 1.3px solid #bed1df;
  border-radius: 2rem;
  color: #252a32;
  background: #ffffff;
  -webkit-transition: all 0.35s ease;
  transition: all 0.35s ease;
}
.main .wrapper .method-item .btn-action:hover {
  background: #cfdde7;
}

</style>
<main class="main" style="background-color: #074e0a">
	<div class="wrapper">
		<div class="card">
			<div class="title">
				<h1 class="title title-large">Sign In</h1>
				<p class="title title-subs">Real time soil fertility analyser using IoT</p>
			</div>
			<form class="form" method="post">
				<div class="form-group">
					<input type="email" name="username" id="email" class="input-field" placeholder="Email address">
				</div>
				<div class="form-group">
					<input type="password" name="password" id="password" class="input-field" placeholder="Password">
				</div>
				<div class="form-group right">
					<!-- <a href="./index.html" class="linktext">Forgot Password</a> -->
					<input type="submit" name="submit" class="input-submit" value="Login">
				</div>
                <br><br>
			</form>
			<div class="line">
				<span class="line-bar"></span>
				<span class="line-text">Or</span>
				<span class="line-bar"></span>
			</div>
			<div class="method">
				<div class="method-item">
					<a href="#" class="btn-action">
						<i class="icons icons-apple fab fa-apple"></i>
						<span>Designed by Theo,Eric and Liesse | Year 2020</span>
					</a>
				</div>
			</div>
		</div>
	</div>
</main>