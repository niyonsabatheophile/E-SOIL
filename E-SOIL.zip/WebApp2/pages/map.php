<style>
    #mapid { height: 700px; }
</style>
<div class="page-card-white">
    <b><h5>Map representation</h5></b>
    <hr>
    <div class="row">
        <div class="col l12">
            <div id="mapid"></div>
        </div>
    </div>
</div>