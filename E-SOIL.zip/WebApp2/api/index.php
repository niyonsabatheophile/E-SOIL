<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Methods: *');
// header("Access-Control-Max-Age: 3600");
header('Access-Control-Allow-Headers: *');

include_once 'db_connection.php';

$ph = $_POST['Ph'];
$sensorValue = $_POST['sensorValue'];
$latitude = $_POST['Latitude'];
$longitude = $_POST['Longitude'];
$location = $_POST['Location'];

if (
    $ph != '' &&
    $ph != 'null' &&
    $sensorValue != ''&&
    $latitude != '' &&
    $longitude != '' &&
    $location != '' && $location != 'null'
) {
    // insert into database
    $registerph = $conn->prepare("INSERT INTO data (location, latitude, longitude, ph, sensorValue) VALUES (:location, :latitude, :longitude, :ph, :sensorValue)");
        $registerph->execute(array(
            ':location' => $location,
            ':latitude' => $latitude,
            ':longitude' => $longitude,
            ':ph' => $ph,
            ':sensorValue'=>$sensorValue,
            
        ));
    echo json_encode(['message' => 'Data saved successfully!']);
}
else{
echo json_encode(['message' => 'Data failed!']);}
?>
