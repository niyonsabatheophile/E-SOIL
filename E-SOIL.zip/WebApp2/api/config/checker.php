<?php
function switchRoutes($uri){
    switch ($uri) {
        case 'client':
        if ($this->clientId) {
            $response = $this->getClient($this->clientId);
        } else {
            $response = $this->getAllClients();
        };
        break;
        case 'POST':
        $response = $this->createUserFromRequest();
        break;
        case 'PUT':
        $response = $this->updateUserFromRequest($this->clientId);
        break;
        case 'DELETE':
        $response = $this->deleteUser($this->clientId);
        break;
        default:
        $response = $this->notFoundResponse();
        break;
    }   
}
?>