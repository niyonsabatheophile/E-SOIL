<?php 

function switchRoutes($uri,$dbConnection){
        global $dbConnection;

    switch ($uri) {
        case 'client':
          $response = clientRoutes($uri,$dbConnection);
        break;
        case 'POST':
        $response = $this->createUserFromRequest();
        break;
        case 'PUT':
        $response = $this->updateUserFromRequest($this->clientId);
        break;
        case 'DELETE':
        $response = $this->deleteUser($this->clientId);
        break;
        default:
        $response = exit("api/");
        break;
    } 
    
    return $response;
}

function clientRoutes($uri,$dbConnection){
    
    // the user id is, of course, optional and must be a number:
    $clientId = null;
    if (isset($uri)) {
        $clientId = $uri;
    }
    $requestMethod = $_SERVER["REQUEST_METHOD"];

    // pass the request method and user ID to the ClientController and process the HTTP request:
    $controller = new ClientController($dbConnection, $requestMethod, $clientId);
    $controller->processRequest();
    }

?>