<?php
namespace Src\Controller;
use Src\System\UiidGeneretor;
use Src\Models\ProductPriceModel;

use Src\Models\ProductionModel;
use Src\Models\ProductTypeModel;
use Src\Models\StockModel;
use Src\System\Session;
use Src\Models\ProductModel;

class StockController {

    private $db;
    private $requestMethod;
    private $stockId;
    private $productTypeModel;
    private $stockModel;
    private $productId;
    private $productModel;
    private $productPriceModel;
    # Object declaration
    private $productionModel;

    public function __construct($db, $requestMethod, $stockId)
    {
        $this->db = $db;
        $this->requestMethod = $requestMethod;
        $this->stockId = $stockId;
        $this->productionModel = new productionModel($db);
        $this->stockModel = new StockModel($db);
        $this->productTypeModel = new ProductTypeModel($db);
        $this->productModel = new ProductModel($db);
        $this->productPriceModel = new ProductPriceModel($db);
    }

    public function processRequest()
    {
        switch ($this->requestMethod) {
            case 'GET':
                if ($this->stockId) {
                    $response = self::getStockById($this->stockId);
                } else {
                    $response = self::getAllStocks();
                }
                break;
            case 'POST':
                $response = $this->createStockFromRequest();
                break;
            default:
                $response = $this->notFoundResponse();
                break;
        }
        header($response['status_code_header']);
        if ($response['body']) {
            echo $response['body'];
        }
    }

    private function getAllStocks()
    {
        $productArr = [];
        $typesArr = [];
        $productsObject = new \stdClass();
        $typesObject = new \stdClass();
        $p = 0;
        $t = 0;
        // Get all product 
        $products = $this->productModel->findAll();

        foreach ($products as $key => $product) {
            $productTypes = $this->productTypeModel->findProdTypeByProdId($product['product_id']);

            foreach ($productTypes as $key => $productType) {
                $productInStock = $this->stockModel->find($productType['product_type_id']);
                $productTypePrices = $this->productPriceModel->findByProductType($productType['product_type_id']);

                $typesObject->product_type_id = $productType['product_type_id'];
                $typesObject->product_type = $productType['product_type'];
                $typesObject->product_description = $productType['product_description'];
                $typesObject->product_quantity = $productInStock[0]['quantity'] ?? 0;
                $typesObject->price_unit = $productTypePrices[0]['price'] ?? 0;
                
                $prodTypeObjectJson = json_encode($typesObject);
                $typesArr[$t] = json_decode($prodTypeObjectJson);
                $t += 1;

            }
            $productsObject->product_id = $product['product_id'];
            $productsObject->product_name = $product['product_name'];
            $productsObject->product_image = $product['product_image'];
            if(sizeof($typesArr) > 0){
                $productsObject->current_stock = $typesArr;
                $prodObjectJson = json_encode($productsObject);
                $productArr[$p] = json_decode($prodObjectJson);
                $p += 1;
            }
        
        }


        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($productArr);
        return $response;
    }
    private function getStockById($stockId)
    {
        $stock = $this->stockModel->find($stockId);
        
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($stock);
        return $response;
    }
    private function createStockFromRequest()
    {
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);

        if (! self::validate($input)) {
            return self::unprocessableEntityResponse();
        }
        $exists = $this->stockModel->find($input['product_type_id']);

        if(sizeof($exists) > 0){
            $input['quantity'] = $input['quantity'] + $exists[0]['quantity'];
            $this->stockModel->update($input);
            return true;
        }else{
           $this->stockModel->insert($input);
            return true;
        }
        return false;
    }
}
?>