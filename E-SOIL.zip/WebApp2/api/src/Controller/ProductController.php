<?php
namespace Src\Controller;
use Src\System\UiidGeneretor;

use Src\Models\ProductModel;
use Src\Models\ProductPriceModel;
use Src\Models\ProductTypeModel;
use Src\Models\ProductImageModel;
use Src\Models\ProductionModel;

class ProductController {

    private $db;
    private $requestMethod;
    private $productId;

    private $productModel;
    private $productPriceModel;
    private $productTypeModel;
    private $productImageModel;
    private $productionModel;
    private $uiidGeneretor;
    private $proId;
    private $action;

    public function __construct($db, $requestMethod, $productId,$proId, $action)
    {
        $this->db = $db;
        $this->requestMethod = $requestMethod;
        $this->productId = $productId;
        $this->proId = $proId;
        $this->action = $action;
        $this->productModel = new ProductModel($db);
        $this->productTypeModel = new ProductTypeModel($db);
        $this->productPriceModel = new ProductPriceModel($db);
        $this->productImageModel = new ProductImageModel($db);
        $this->productionModel = new ProductionModel($db);
        $this->uiidGeneretor = new UiidGeneretor();



    }

    public function processRequest()
    {
        switch ($this->requestMethod) {
            case 'GET':
                if ($this->productId) {
                    if ($this->productId !== 'details' && $this->proId == '') {
                        $response = self::getProduct($this->productId);
                    } elseif ($this->productId == 'details' && !empty($this->proId)) {
                        $response = self::getProductByIdDetails($this->proId);
                    } else {
                        $response = self::getProductDetails();
                    }
                } else {
                    $response = self::getAllProducts();
                };
                break;
            case 'POST':
                if ($this->action == 'update') {
                    $response = self::updateProductFromRequest($this->productId);
                } else {
                    $response = self::createProductFromRequest();
                }
                break;
            case 'PUT':
                $response = self::updateProductFromRequest($this->productId);
                break;
            case 'DELETE':
                $response = self::deleteProduct($this->productId);
                break;
            default:
                $response = self::notFoundResponse();
                break;
        }
        header($response['status_code_header']);
        if ($response['body']) {
            echo $response['body'];
        }else{
            echo $response['body'];
        }
    }

    private function getAllProducts()
    {
        $result = $this->productModel->findAll();
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($result);
        return $response;
    }

    private function getProduct($id)
    {
        $result = $this->productModel->find($id);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($result);
        return $response;
    }

    private function getProductDetails() 
    {
        $productArr = [];
        $productTypes = [];
        $productsObject = new \stdClass();
        $productTypesObject = new \stdClass();
        $x = 0;
        $y = 0;
        $products = $this->productModel->findAll();

        foreach ($products as $product) {
            $productTypes = $this->productTypeModel->findProdTypeByProdId($product['product_id']);

            foreach ($productTypes as $productType) {
                $productTypePrices = $this->productPriceModel->findByProductType($productType['product_type_id']);
                $productTypeImgs = $this->productImageModel->findByProductType($productType['product_type_id']);
                $productions = $this->productionModel->findByProductTypeId($productType['product_type_id']);
                
                $productTypesObject->product_type_id = $productType['product_type_id'];
                $productTypesObject->product_type = $productType['product_type'];
                $productTypesObject->product_description = $productType['product_description'];
                $productTypesObject->product_price = $productTypePrices[0]['price'] ?? null;
                $productTypesObject->product_image = $productTypeImgs[0]['image'] ?? null;
                $prodQuantity = [];
                $i = 0;
                // Calculate tatal production quantitis of same product type

                foreach ($productions as $key => $quant) {
                    foreach ($quant as $key => $value) {
                        if($productions[0]['product_type_id'] === $quant['product_type_id']){
                            $prodQuantity[$i] = $quant['quantity'];
                        }
                    }
                    $i +=1;
                }
                
                $productTypesObject->product_quantity = array_sum($prodQuantity) ?? null;

                $prodTypeObjectJson = json_encode($productTypesObject);
                $productTypes[$y] = json_decode($prodTypeObjectJson);
                
                $y +=1;

            }
            $productsObject->product_id = $product['product_id'];
            $productsObject->product_name = $product['product_name'];
            $productsObject->product_image = $product['product_image'];
            $productsObject->productTypes = $productTypes;
            $prodObjectJson = json_encode($productsObject);
            $productArr[$x] = json_decode($prodObjectJson);
            
            $x +=1;

        }
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($productArr);
        return $response;
    }

    private function getProductByIdDetails($proId) 
    {
        $productArr = [];
        $productTypes = [];
        $productsObject = new \stdClass();
        $productTypesObject = new \stdClass();
        $x = 0;
        $y = 0;
        
        $products = $this->productModel->find($proId);

        if ($products) {
            $productTypes = $this->productTypeModel->findProdTypeByProdId($products[0]['product_id']);

            foreach ($productTypes as $productType) {
                $productTypePrices = $this->productPriceModel->findByProductType($productType['product_type_id']);
                $productTypeImgs = $this->productImageModel->findByProductType($productType['product_type_id']);
                $productions = $this->productionModel->findByProductTypeId($productType['product_type_id']);

                $productTypesObject->product_type_id = $productType['product_type_id'];
                $productTypesObject->product_type = $productType['product_type'];
                $productTypesObject->product_description = $productType['product_description'];
                $productTypesObject->product_price = $productTypePrices[0]['price'] ?? null;
                $productTypesObject->product_image = $productTypeImgs[0]['image'] ?? null;
                $productTypesObject->product_quantity = $productions[0]['quantity'] ?? null;

                $prodTypeObjectJson = json_encode($productTypesObject);
                $productTypes[$y] = json_decode($prodTypeObjectJson);
                
                $y +=1;

            }
            $productsObject->product_id = $products[0]['product_id'];
            $productsObject->product_name = $products[0]['product_name'];
            $productsObject->product_image = $products[0]['product_image'];
            $productsObject->productTypes = $productTypes;
            $prodObjectJson = json_encode($productsObject);
            $productArr[$x] = json_decode($prodObjectJson);
            
            $x +=1;

        }
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($productArr);
        return $response;
    }
    private function createProductFromRequest()
    {
        //$input = (array) json_decode(file_get_contents('php://input'), TRUE);
        // Validating an image before being uploaded

        $msg = ["product_name"=> $_POST['product_name'],"product_image" => $_FILES["product_image"]["name"]];
        if(isset($_FILES) && !empty($_FILES['product_image']['name'])) {
            $target_dir = 'public/product-image/';
            $product_img = time().basename($_FILES['product_image']['name']);
            $fileToMove = $target_dir.$product_img;
        }else{
            return $this->unprocessableEntityResponse();
        }
        // Validating product name

        $input['product_id'] = $this->uiidGeneretor->guid();
        $input['product_name'] = $_POST['product_name'];
        $input['product_image'] = $fileToMove;

        if (! $this->validateProduct($input)) {
            return $this->unprocessableEntityResponse();
        }

        if (move_uploaded_file($_FILES["product_image"]["tmp_name"], $fileToMove)) {
            $this->productModel->insert($input);
        }else{
            $msg = "failed";
        }
        $response['status_code_header'] = 'HTTP/1.1 201 Created';
        $response['body'] = $msg;
        return $response;
    }
    private function updateProductFromRequest()
    {
        // $input = (array) json_decode(file_get_contents('php://input'), TRUE);
        $fileToMove = '';
        $result = $this->productModel->find($_POST['product_id']);
        if (! $result) {
            return $this->notFoundResponse();
        }
        if(isset($_FILES) && !empty($_FILES['product_image']['name'])) {
            $target_dir = 'public/product-image/';
            $product_img = time().basename($_FILES['product_image']['name']);
            $fileToMove = $target_dir.$product_img;
        }
        $input['product_id'] = $_POST['product_id'];
        $input['product_name'] = $_POST['product_name'];
        $input['product_image'] = $fileToMove;
        if(empty($fileToMove)){
            $this->productModel->updateName($input);
        }else{
            move_uploaded_file($_FILES["product_image"]["tmp_name"], $fileToMove);
            $this->productModel->update($input);
        }
        
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = null;
        return $response;
    }

    private function deleteProduct($id)
    {
        $result = $this->productModel->find($id);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $this->productModel->delete($id);
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = null;
        return $response;
    }

    private function validateProduct($input)
    {
        if (empty($input['product_id'])) {
            return false;
        }
        if (empty($input['product_name'])) {
            return false;
        }
        if (empty($input['product_image'])) {
            return false;
        }
        return true;
    }

    private function unprocessableEntityResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 422 Unprocessable Entity';
        $response['body'] = json_encode([
            'error' => 'Invalid input'
        ]);
        return $response;
    }
    private function notFoundResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 404 Not Found';
        $response['body'] = json_encode(["status" => 404, "msg" =>"Not Found"]);
        return $response;
    }
    private function AuthFail()
    {
        $response['status_code_header'] = 'HTTP/1.1 203 Non-Authoritative Information!';
        $response['body'] = json_encode(["status" => 203, "msg" =>"Authication failed!"]);
        return $response;
    }
}
    ?>