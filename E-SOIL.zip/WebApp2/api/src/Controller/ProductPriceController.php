<?php
namespace Src\Controller;

use Src\Models\ProductTypeModel;
use Src\Models\ProductModel;
// use Src\Models\ProductPriceModel;

class ProductPriceController {

    private $db;
    private $requestMethod;
    private $productTypeId;

    private $productTypeModel;
    private $productModel;
    private $productPriceModel;

    public function __construct($db, $requestMethod, $productTypeId)
    {
        $this->db = $db;
        $this->requestMethod = $requestMethod;
        $this->productTypeId = $productTypeId;
        $this->productTypeModel = new ProductTypeModel($db);
        $this->productModel = new ProductModel($db);
    }

    public function processRequest()
    {
        switch ($this->requestMethod) {
            case 'GET':
                if ($this->productTypeId) {
                    $response = $this->getProductType($this->productTypeId);
                } else {
                    $response = $this->getAllProductTypes();
                };
                break;
            case 'POST':
                $response = $this->createProductFromRequest();
                break;
            case 'PUT':
                $response = $this->updateUserFromRequest($this->productTypeId);
                break;
            case 'DELETE':
                $response = $this->deleteUser($this->productTypeId);
                break;
            default:
                $response = $this->notFoundResponse();
                break;
        }
        header($response['status_code_header']);
        if ($response['body']) {
            echo $response['body'];
        }else{
            echo $response['body'];
        }
    }

    private function getAllProductTypes()
    {
        $result = $this->productTypeModel->findAll();
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($result);
        return $response;
    }

    private function getProductType($id)
    {
        $result = $this->productTypeModel->find($id);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($result);
        return $response;
    }

    private function createProductFromRequest()
    {
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);
        if (! $this->validateProduct($input)) {
            return $this->unprocessableEntityResponse();
        }
        // Chech if product is already exist
        $result = $this->productModel->find($input['product_id']);
        if (! $result) {
            return $this->notFoundResponse();
        }
        // Chech if product price is already set
        $result = $this->productModel->find($input['product_type_id']);
        if ($result) {
            $result = $this->productPriceModel->updatePrice($result['product_price_id']);
            if($result){
                $this->productPriceModel->insert($input);
            }
        }else{
            $this->productPriceModel->insert($input);
        }
        // Chech if product image is already set

        $this->productTypeModel->insert($input);

        $response['status_code_header'] = 'HTTP/1.1 201 Created';
        $response['body'] = null;
        return $response;
    }
    private function updateProductFromRequest($id)
    {
        $result = $this->productTypeModel->find($id);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);
        if (! $this->validateProduct($input)) {
            return $this->unprocessableEntityResponse();
        }
        $this->productTypeModel->update($id, $input);
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = null;
        return $response;
    }

    private function deleteProduct($id)
    {
        $result = $this->productTypeModel->find($id);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $this->productTypeModel->delete($id);
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = null;
        return $response;
    }

    private function validateProduct($input)
    {
        if (empty($input['product_type_id'])) {
            return false;
        }
        if (empty($input['product_type'])) {
            return false;
        }
        if (empty($input['product_id'])) {
            return false;
        }
        return true;
    }

    private function unprocessableEntityResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 422 Unprocessable Entity';
        $response['body'] = json_encode([
            'error' => 'Invalid input'
        ]);
        return $response;
    }
    private function notFoundResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 404 Not Found';
        $response['body'] = json_encode(["status" => 404, "msg" =>"Not Found"]);
        return $response;
    }
}
    ?>