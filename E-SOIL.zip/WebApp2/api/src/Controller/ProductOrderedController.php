<?php
namespace Src\Controller;

use Src\Models\OrderModel;
use Src\Models\ProductTypeModel;
use Src\Models\ProductOrderedModel;

class ProductOrderedController {

    private $db;
    private $requestMethod;
    private $productOrderedId;

    private $orderModel;
    private $productTypeModel;
    private $productOrderedModel;
    public function __construct($db, $requestMethod, $productOrderedId)
    {
        $this->db = $db;
        $this->requestMethod = $requestMethod;
        $this->productOrderedId = $productOrderedId;
        $this->orderModel = new OrderModel($db);
        $this->productTypeModel = new ProductTypeModel($db);
        $this->productOrderedModel = new ProductOrderedModel($db);

    }

    public function processRequest()
    {
        switch ($this->requestMethod) {
            case 'GET':
                if ($this->productOrderedId) {
                    $response = self::getProductOrdeedr($this->productOrderedId);
                } else {
                    $response = self::getAllProductOrdereds();
                };
                break;
            case 'POST':
                $response = $this->createProductOrderFromRequest();
                break;
            case 'PUT':
                $response = $this->updateOrderFromRequest($this->productOrderedId);
                break;
            case 'PATCH':
                $response = $this->deleteProdOrdered();
                break;
            default:
                $response = $this->notFoundResponse();
                break;
        }
        header($response['status_code_header']);
        if ($response['body']) {
            echo $response['body'];
        }else{
            echo $response['body'];
        }
    }

    private function getAllProductOrdereds()
    {
        $result = $this->orderModel->findAll();
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($result);
        return $response;
    }

    private function getProductOrdered($id)
    {
        $result = $this->orderModel->find($id);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($result);
        return $response;
    }

    private function getProductTypeDetails() 
    {
        $products = $this->orderModel->findAll();
        foreach ($products as $key => $product) {
            
        }
    }

    private function createOrderFromRequest()
    {
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);
        if (! $this->validateOrder($input)) {
            return $this->unprocessableEntityResponse();
        }

        if(! $this->clientModel->find($input['client_id'])) {
            return $this->notFoundResponse();
        }

        $this->orderModel->insert($input);
        $response['status_code_header'] = 'HTTP/1.1 201 Created';
        $response['body'] = null;
        return $response;
    }
    private function updateProductFromRequest($id)
    {
        $result = $this->orderModel->find($id);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);
        if (! $this->validateProduct($input)) {
            return $this->unprocessableEntityResponse();
        }
        $this->orderModel->update($id, $input);
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = null;
        return $response;
    }

    private function deleteProdOrdered()
    {
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);

        $result = $this->productOrderedModel->find($input['product_ordered_id']);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $this->productOrderedModel->delete($input['product_ordered_id']);
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = null;
        return $response;
    }

    private function validateOrder($input)
    {
        if (empty($input['product_ordered_id'])) {
            return false;
        }
        return true;
    }

    private function unprocessableEntityResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 422 Unprocessable Entity';
        $response['body'] = json_encode([
            'error' => 'Invalid input'
        ]);
        return $response;
    }
    private function notFoundResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 404 Not Found';
        $response['body'] = json_encode(["status" => 404, "msg" =>"Not Found"]);
        return $response;
    }
}
?>