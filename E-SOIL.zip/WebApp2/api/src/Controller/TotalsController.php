<?php
namespace Src\Controller;
use Src\System\Session;
use Src\System\Token;

use Src\Models\ProductModel;
use Src\Models\ProductTypeModel;
use Src\Models\ProductionModel;
use Src\Models\SupplierModel;
use Src\Models\ClientModel;
use Src\Models\OrderModel;

class TotalsController {
    private $db;
    private $requestMethod;
    private $thing;
    private $status;

    private $productModel;
    private $productTypeModel;
    private $productionModel;
    private $supplierModel;
    private $clientModel;
    private $orderModel;

    public function __construct($db, $requestMethod, $thing, $status)
    {
        $this->db = $db;
        $this->requestMethod = $requestMethod;
        $this->thing = $thing;
        $this->status = $status;
        
        $this->productModel = new ProductModel($db);
        $this->productTypeModel = new ProductTypeModel($db);
        $this->productionModel = new ProductionModel($db);
        $this->supplierModel = new SupplierModel($db);
        $this->clientModel = new ClientModel($db);
        $this->orderModel = new OrderModel($db);


    }

    public function processRequest()
    {
        if($this->requestMethod == 'GET'){
            switch ($this->thing) {
                case 'summary':
                    $response = self::getAllTotals();
                    break;
                case 'products':
                    $response = self::getTotalProducts();
                    break;
                case 'product_types':
                    $response = self::getTotalProductTypes();
                    break;
                case 'productions':
                    $response = self::getTotalProductions();
                    break;
                case 'suppliers':
                    $response = self::getTotalSuppliers();
                    break;
                case 'clients':
                    $response = self::getTotalClients();
                    break;
                case 'orders':
                    if($this->status == 0){
                        $response = self::getTotalPendingOrders();
                    }elseif($this->status == 1){
                        $response = self::getTotalCompletedOrders();
                    }else{
                        $response = self::getTotalOrders();
                    }
                    break;
                default:
                    $response = self::notFoundResponse();
                    break;
            }
        }
        header($response['status_code_header']);
        if ($response['body']) {
             echo $response['body'];
        }
    }
    private function getAllTotals(){
        $all_totals = [];
        $all_totals['total_products'] = count($this->productModel->findAll());
        $all_totals['total_pro_types'] = count($this->productTypeModel->findAll());
        $all_totals['total_productions'] = count($this->productionModel->findAll());
        $all_totals['total_suppliers'] = count($this->supplierModel->findAll());
        $all_totals['total_clients'] = count($this->clientModel->findAll());
        $all_totals['total_orders'] = count($this->orderModel->findAll());
        $all_totals['total_pending'] = count($this->orderModel->findPending());
        $all_totals['total_complete'] = count($this->orderModel->findComplete());

        $response['status_code_header'] = 'HTTP/1.1 200 Ok';
        $response['body'] = json_encode($all_totals);
        return $response;
    }
    private function getTotalProducts() {
        $total_pro = $this->productModel->findAll();

        $response['status_code_header'] = 'HTTP/1.1 201 Created';
        $response['body'] = json_encode(["total_products"=>count($total_pro)]);
        return $response;
    }
    private function getTotalProductTypes() {
        $total_proTypes = $this->productTypeModel->findAll();

        $response['status_code_header'] = 'HTTP/1.1 201 Created';
        $response['body'] = json_encode(["total_pro_types"=>count($total_proTypes)]);
        return $response;
    }
    private function getTotalProductions() {
        $total_production = $this->productionModel->findAll();

        $response['status_code_header'] = 'HTTP/1.1 201 Created';
        $response['body'] = json_encode(["total_productions"=>count($total_production)]);
        return $response;
    }
    private function getTotalSuppliers() {
        $total_supplier = $this->supplierModel->findAll();

        $response['status_code_header'] = 'HTTP/1.1 201 Created';
        $response['body'] = json_encode(["total_suppliers"=>count($total_supplier)]);
        return $response;
    }
    private function getTotalClients() {
        $total_clients = $this->clientModel->findAll();

        $response['status_code_header'] = 'HTTP/1.1 201 Created';
        $response['body'] = json_encode(["total_clients"=>count($total_clients)]);
        return $response;
    }
    private function getTotalOrders() {
        $total_order = $this->orderModel->findAll();

        $response['status_code_header'] = 'HTTP/1.1 201 Created';
        $response['body'] = json_encode(["total_order"=>count($total_order)]);
        return $response;
    }
    private function getTotalPendingOrders() {
        $total_pending = $this->orderModel->findPending();

        $response['status_code_header'] = 'HTTP/1.1 201 Created';
        $response['body'] = json_encode(["total_pending"=>count($total_pending)]);
        return $response;
    }
    private function getTotalCompletedOrders() {
        $total_complete = $this->orderModel->findComplete();

        $response['status_code_header'] = 'HTTP/1.1 201 Created';
        $response['body'] = json_encode(["total_complete"=>count($total_complete)]);
        return $response;
    }
    private function notFoundResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 404 Not Found';
        $response['body'] = json_encode(["status" => 404, "msg" =>"Not Found"]);
        return $response;
    }
}

?>