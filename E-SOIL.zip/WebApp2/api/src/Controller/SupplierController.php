<?php
namespace Src\Controller;
use Src\System\Session;

use Src\Models\SupplierModel;
use Src\System\Token;

class SupplierController {

    private $db;
    private $requestMethod;
    private $supplierId;
    private $supplierModel;

    public function __construct($db, $requestMethod, $supplierId)
    {
        $this->db = $db;
        $this->requestMethod = $requestMethod;
        $this->supplierId = $supplierId;
        $this->supplierModel = new SupplierModel($db);
    }

    public function processRequest()
    {
        switch ($this->requestMethod) {
            case 'GET':
                if (Token::checkToken(Token::getToken("ADMIN_TOKEN"),"ADMIN_TOKEN")) {
                    if ($this->supplierId) {
                        $response = $this->getSupplierById($this->supplierId);
                    } else {
                        $response = $this->getAllSuppliers();
                    }
                }else{
                    $response = self::AuthFail();
                }
                break;
            case 'POST':
                if (Token::checkToken(Token::getToken("ADMIN_TOKEN"),"ADMIN_TOKEN")) {
                    $response = $this->createSuppierFromRequest();
                }else{
                    $response = self::AuthFail();
                }
                break;
            case 'PUT':
                if (Token::checkToken(Token::getToken("ADMIN_TOKEN"),"ADMIN_TOKEN")) {
                    $response = $this->updateSupplierFromRequest($this->supplierId);
                }else{
                    $response = self::AuthFail();
                }
                break;
            case 'DELETE':
                if (Token::checkToken(Token::getToken("ADMIN_TOKEN"),"ADMIN_TOKEN")) {
                    $response = $this->deleteSupplier($this->supplierId);
                }else{
                    $response = self::AuthFail();
                }
                break;
            default:
                $response = $this->notFoundResponse();
                break;
        }
        header($response['status_code_header']);
        if ($response['body']) {
            echo $response['body'];
        }else{
            echo ($response['body']);
        }
    }

    private function getAllSuppliers()
    {
        $result = $this->supplierModel->findAll();
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($result);
        return $response;
    }

    private function getSupplierById($id)
    {
        $result = $this->supplierModel->find($id);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($result);
        return $response;
    }

    private function createSuppierFromRequest()
    {
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);
        if (! self::validateClient($input)) {
            return self::unprocessableEntityResponse();
        }
        // Check if client is registered
            $this->supplierModel->insert($input);

            $response['status_code_header'] = 'HTTP/1.1 201 Created';
            $response['body'] = null;
            return $response;
    }

    private function updateSupplierFromRequest($id)
    {
        $result = $this->supplierModel->find($id);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);
        if (! $this->validateClient($input)) {
            return $this->unprocessableEntityResponse();
        }
        $this->supplierModel->update($id, $input);
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = null;
        return $response;
    }

    private function deleteSupplier($id)
    {
        $result = $this->supplierModel->find($id);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $this->supplierModel->delete($id);
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = null;
        return $response;
    }

    private function validateClient($input)
    {
        if (empty($input['fname'])) {
            return false;
        }
        if (empty($input['lname'])) {
            return false;
        }
        if (empty($input['phone_number'])) {
            return false;
        }
        return true;
    }

    private function unprocessableEntityResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 422 Unprocessable Entity';
        $response['body'] = json_encode([
            'error' => 'Invalid input'
        ]);
        return $response;
    }

    private function notFoundResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 404 Not Found';
        $response['body'] = json_encode(["status" => 404, "msg" =>"Not Found"]);
        return $response;
    }
    private function AuthFail()
    {
        $response['status_code_header'] = 'HTTP/1.1 203 Non-Authoritative Information!';
        $response['body'] = json_encode(["status" => 203, "msg" =>"Authication failed!"]);
        return $response;
    }
}