<?php
namespace Src\Controller;

use Src\System\Token;
use Src\Models\ClientModel;

class TokenController {
    private $requestMethod;
    private $clientModel;
    private $who;

    public function __construct($requestMethod,$who) {
        $this->requestMethod = $requestMethod;
        $this->who = $who;
    }
    public function processRequest()
    {
        switch ($this->requestMethod) {
            case 'GET':
                if ($this->who === 'admin') {
                    $response = self::getAdminTokenAndSession();
                }else{
                    $response = self::getTokenAndSession();
                }
                break;
            default:
                $response = self::notFoundResponse();
                break;
        }
        header($response['status_code_header']);
        if ($response['body']) {
            echo $response['body'];
        }
    }
    public function getTokenAndSession() {

        if(isset($_SESSION['USER_TOKEN'])){
            $response['status_code_header'] = 'HTTP/1.1 200 success!';
            $response['body'] = json_encode($_SESSION);
            return $response;
        }else{
            $response['status_code_header'] = 'HTTP/1.1 203 Non-Authoritative Information!';
            $response['body'] = json_encode(["msg" => "Empty client!"]);
            return $response;
        }
    }
    public function getAdminTokenAndSession() {

        if(isset($_SESSION['ADMIN_TOKEN'])){
            $response['status_code_header'] = 'HTTP/1.1 200 success!';
            $response['body'] = json_encode($_SESSION);
            return $response;
        }else{
            $response['status_code_header'] = 'HTTP/1.1 203 Non-Authoritative Information!';
            $response['body'] = json_encode(["msg" => "Empty admin!"]);
            return $response;
        }
    }
    private function notFoundResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 404 Not Found';
        $response['body'] = json_encode(["status" => 404, "msg" =>"Not Found"]);
        return $response;
    }
}

?>