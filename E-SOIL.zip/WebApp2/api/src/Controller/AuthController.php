<?php
namespace Src\Controller;
use Src\System\Session;

use Src\Models\AdminModel;
use Src\Models\ClientModel;
use Src\System\Token;
use Src\System\Encript;

class AuthController {

    private $db;
    private $requestMethod;
    private $who;

    private $adminModel;
    private $clientModel;

    public function __construct($db, $requestMethod, $who)
    {
        $this->db = $db;
        $this->requestMethod = $requestMethod;
        $this->who = $who;
        $this->clientModel = new ClientModel($db);
        $this->adminModel = new AdminModel($db);
    }

    public function processRequest()
    {
        switch ($this->requestMethod) {
            case 'POST':
                if ($this->who === 'admin') {
                    $response = self::adminLoginRequest();
                } elseif ($this->who === 'client') {
                    $response = self::clientLoginRequest();
                }else{
                    $response = self::notFoundResponse();
                }
            break;
            case 'DELETE':
                if ($this->who === 'admin') {
                    if (Token::checkToken(Token::getToken("ADMIN_TOKEN"),"ADMIN_TOKEN")) {
                        $response = self::logOut();
                    } else {
                        $response = self::logOut();
                    }
                }else{
                    //if (Token::checkToken(Token::getToken("USER_TOKEN"),"USER_TOKEN")) {
                        $response = self::logOut();
                    //} else {
                        //$response = self::logOut();
                    //}
                }
            break;
            default:
                $response = self::notFoundResponse();
                break;
        }
        header($response['status_code_header']);
        if ($response['body']) {
            echo $response['body'];
        }else{
            echo ($response['body']);
        }
    }
    // Client login function
    private function clientLoginRequest(){
        $input = (array) json_decode(file_get_contents('php://input'), TRUE); 
        // Validate input if not empty
        if(! self::validateClient($input)){
            return self::unprocessableEntityResponse();
        }
        // Found if user is has account
        if($result = $this->clientModel->findByEmail($input['email'])) {
            $input_password = Encript::saltEncription($input['password']);

            if($input_password === $result[0]['password']){
                Session::put("client_id",$result[0]['client_id']);
                Session::put("email",$result[0]['email']);
                if(Token::generate("USER_TOKEN")){
                    Token::setTokenExpire();
                }

                $response['status_code_header'] = 'HTTP/1.1 200 success!';
                $response['body'] = json_encode([
                'msg' => "Welcome"
                ]);
                return $response;
            }
            $response['status_code_header'] = 'HTTP/1.1 422 Unprocessable Entity';
            $response['body'] = json_encode([
            'msg' => 'Username/password does not match'
            ]);
            return $response;
        }else{
            $response['status_code_header'] = 'HTTP/1.1 422 Unprocessable Entity';
            $response['body'] = json_encode([
            'msg' => 'Username/password does not match'
            ]);
            return $response;
        }


    }
        // Admin login function
    private function adminLoginRequest(){
        $input = (array) json_decode(file_get_contents('php://input'), TRUE); 
        // Validate input if not empty
        if(! self::validateClient($input)){
            return self::unprocessableEntityResponse();
        }
        // Found if user is has account
        if($result = $this->adminModel->findByEmail($input['email'])) {
            $input_password = Encript::saltEncription($input['password']);

            if($input_password === $result[0]['password']){
                if(Token::generate("ADMIN_TOKEN")){
                    Token::setTokenExpire();
                }
                Session::put("user_id",$result[0]['user_id']);
                Session::put("email",$result[0]['email']);

                $response['status_code_header'] = 'HTTP/1.1 200 success!';
                $response['body'] = json_encode([
                'msg' => 'Welcome!'
                ]);
                return $response;
            }
            $response['status_code_header'] = 'HTTP/1.1 422 Unprocessable Entity';
            $response['body'] = json_encode([
            'msg' => 'Username/password does not match'
            ]);
            return $response;
        }else{
            $response['status_code_header'] = 'HTTP/1.1 422 Unprocessable Entity';
            $response['body'] = json_encode([
            'msg' => 'Username/password does not match'
            ]);
            return $response;
        }

    }

    private function validateClient($input)
    {
        if (empty($input['email'])) {
            return false;
        }
        if (empty($input['password'])) {
            return false;
        }

        return true;
    }

    private function unprocessableEntityResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 422 Unprocessable Entity';
        $response['body'] = json_encode([
            'error' => 'Invalid input'
        ]);
        return $response;
    }

    private function notFoundResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 404 Not Found';
        $response['body'] = json_encode(["status" => 404, "msg" =>"Not Found"]);
        return $response;
    }

    private function logOut() {
        Session::guturitsa();
        
        $response['status_code_header'] = 'HTTP/1.1 200 ok';
        $response['body'] = json_encode(["status" => 200, "msg" =>"well"]);
        return $response;
    }
    private function AuthFail()
    {
        $response['status_code_header'] = 'HTTP/1.1 203 Non-Authoritative Information!';
        $response['body'] = json_encode(["status" => 203, "msg" =>"Authotication failed!"]);
        return $response;
    }
}