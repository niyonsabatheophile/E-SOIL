<?php
namespace Src\Controller;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

use Src\System\Session;
use Src\System\Token;
use Src\Models\ClientModel;
use Src\Models\SendEmailModel;
use Src\Models\ClientActionModel;
use Src\System\Encript;

class SendEmailController {

    private $db;
    private $action;
    private $requestMethod;
    private $clientModel;
    private $sendEmailModel;
    private $clientActionModel;

    public function __construct($db, $requestMethod, $action)
    {
        $this->db = $db;
        $this->action = $action;
        $this->requestMethod = $requestMethod;
        $this->clientModel = new ClientModel($db);
        $this->clientActionModel = new ClientActionModel($db);
    }
    public function processRequest()
    {
        switch ($this->requestMethod) {
            case 'POST':
                if($this->action === "fpwd"){
                    $response = self::sendEmail();
                }else{
                    $response = self::notFoundResponse();
                }
                break;
            default:
                $response = self::notFoundResponse();
                break;
        }
        header($response['status_code_header']);
        if ($response['body']) {
            echo $response['body'];
        }
    }

    private function sendEmail()
    {
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);

        $new_password = Encript::generatePassword(10);
        $input['new_password'] = Encript::saltEncription($new_password);

        if(self::validateClient($input) <= 0){
            return self::unprocessableEntityResponse();
        }

        $clientData = $this->clientModel->findByEmail($input['email']);
        
        if(sizeof($clientData) > 0) {
            // if(Token::generate("LOGIN_TOKEN")){
            //     Token::setTokenExpire();
            //     $action = $this->clientActionModel->find($clientData[0]['client_id']);
            //     if(sizeof($action) > 0){
            //         if($this->clientActionModel->update(["client_activity_id" => $action[0]['client_activity_id']])) {
            //             $this->clientActionModel->insert(["client_id" => $clientData[0]['client_id'],"token" => Token::getToken("LOGIN_TOKEN")]);
            //         }
            //     }else{
            //         $this->clientActionModel->insert(["client_id" => $clientData[0]['client_id'],"token" => Token::getToken("LOGIN_TOKEN")]);
            //     }
            // }
            $message = "
            Dear ".$clientData[0]['lname']."
            Your request of forgeting password accepted <br>
            please, use this password for login <label style='color: darkgreen;'><strong>".$new_password."</strong></label>"; 

        }else{
            return self::emailNotFoundResponse();
        }
        // Load Composer's autoloader
        require 'vendor/autoload.php';

        // Instantiation and passing `true` enables exceptions
        $mail = new PHPMailer(true);

        try {
            //Server settings
            $mail->SMTPDebug = 0;                                       // Enable verbose debug output
            $mail->isSMTP();                                            // Set mailer to use SMTP
            $mail->Host       = 'mail.hackflix.net';  // Specify main and backup SMTP servers
            $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
            $mail->Username   = 'ingabo@fieldforce.rw';                     // SMTP username
            $mail->Password   = 'egKHwi4G11';                               // SMTP password
            $mail->SMTPSecure = 'ssl';//PHPMailer::ENCRYPTION_STARTTLS;                                  // Enable TLS encryption, `ssl` also accepted
            $mail->Port       = 465;                                    // TCP port to connect to

            //Recipients
            $mail->setFrom('ingabo@fieldforce.rw', 'Mailer');
            $mail->addAddress($input['email'], 'Joseph');     // Add a recipient
            $mail->addAddress($input['email']);               // Name is optional

            // Content
            $mail->isHTML(true);                                  // Set email format to HTML
            $mail->Subject = 'Here is the subject';
            $mail->Body    = $message;
            $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

            $mail->send();
            if($mail){
                $this->clientModel->updatePassword($clientData[0]['client_id'], $input);
                return self::SentMsg();
            }else{
                return self::notSentMsg();
            }
        } catch (Exception $e) {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    }
    private function notSentMsg() {
        $response['status_code_header'] = 'HTTP/1.1 203 Failed';
        $response['body'] = json_encode(['msg' => "Email not sent!"]);
        return $response;
    }
    private function SentMsg() {
        $response['status_code_header'] = 'HTTP/1.1 200 Ok';
        $response['body'] = json_encode(['msg' => "Email sent!"]);
        return $response;
    }
    private function notFoundResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 404 Not Found';
        $response['body'] = json_encode(["status" => 404, "msg" =>"Not Found"]);
        return $response;
    }
    private function emailNotFoundResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 404 Not Found';
        $response['body'] = json_encode(["status" => 404, "msg" =>"Username/Emal not found!"]);
        return $response;
    }
    private function unprocessableEntityResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 422 Unprocessable Entity';
        $response['body'] = json_encode([
            'error' => 'Invalid input'
        ]);
        return $response;
    }
    private function validateClient($input)
    {
        return sizeof($input);
    }
}
?>