<?php
namespace Src\Controller;

use Src\Models\PaymentModel;
use Src\Models\OrderModel;
use Src\Models\ProductOrderedModel;
use Src\Models\StockModel;

class PaymentCallbackController {

    private $db;
    private $requestMethod;
    private $clientId;
    private $paymentModel;
    private $OrderModel;
    private $productOrderedModel;
    private $stockModel;

    public function __construct($db, $requestMethod)
    {
        $this->db = $db;
        $this->requestMethod = $requestMethod;
        $this->clientId = $clientId;
        $this->paymentModel = new PaymentModel($db);
        $this->OrderModel = new OrderModel($db);
        $this->productOrderedModel = new ProductOrderedModel($db);
        $this->stockModel = new StockModel($db);
    }
    public function processRequest()
    {
        switch ($this->requestMethod) {
            case 'POST':
                $response = self::createPaymentFromRequest();
                break;
            default:
                $response = self::notFoundResponse();
                break;
        }
        header($response['status_code_header']);
        if ($response['body']) {
            echo $response['body'];
        }else{
            echo ($response['body']);
        }
    }

    private function createPaymentFromRequest()
    {
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);
        $orderData = $this->paymentModel->findByWalletTransId($input);

        // Check if client is registered
        
        if(sizeof($orderData) > 0){

            if($this->paymentModel->update($input)){
                if($input['statusCode'] == 200){
                    $this->OrderModel->update($orderData);
                    $productOrdered = $this->productOrderedModel->findByOrder($orderData[0]['order_id']);

                    foreach ($productOrdered as $key => $product) {
                        $exists = $this->stockModel->find($product['product_type_id']);

                        if(sizeof($exists) > 0){
                            if($exists[0]['quantity'] >= $product['quantity']){
                                $input['product_type_id'] = $product['product_type_id'];
                                $input['quantity'] = $exists[0]['quantity'] - $product['quantity'];
                                $this->stockModel->update($input);
                            }
                        }

                    }
                }
            }
        }

        $response['status_code_header'] = 'HTTP/1.1 201 Created';
        $response['body'] = null;
        return $response;
    }
    private function unprocessableEntityResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 422 Unprocessable Entity';
        $response['body'] = json_encode([
            'error' => 'Invalid input'
        ]);
        return $response;
    }

    private function notFoundResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 404 Not Found';
        $response['body'] = json_encode(["status" => 404, "msg" =>"Not Found"]);
        return $response;
    }
}
?>