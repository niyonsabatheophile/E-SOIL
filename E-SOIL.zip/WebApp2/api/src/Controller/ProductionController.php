<?php
namespace Src\Controller;

use Src\Models\ProductionModel;
use Src\Models\ProductTypeModel;
use Src\Models\StockModel;
use Src\System\Session;
use Src\Models\ProductModel;
use Src\Models\ProductPriceModel;
use Src\System\Token;

class ProductionController {

    private $db;
    private $requestMethod;
    private $productId;
    private $stockModel;

    # Object declaration
    private $productModel;
    private $productPriceModel;
    # Object declaration
    private $productionModel;
    private $productTypeModel;

    public function __construct($db, $requestMethod, $productId)
    {
        $this->db = $db;
        $this->requestMethod = $requestMethod;
        $this->productId = $productId;
        $this->productionModel = new productionModel($db);
        $this->stockModel = new StockModel($db);
        $this->productTypeModel = new ProductTypeModel($db);
        $this->productModel = new ProductModel($db);
        $this->productPriceModel = new ProductPriceModel($db);
    }

    public function processRequest()
    {
        switch ($this->requestMethod) {
            case 'GET':
                if (Token::checkToken(Token::getToken("ADMIN_TOKEN"),"ADMIN_TOKEN")) {
                    if ($this->productId) {
                        $response = $this->getProduction($this->productId);
                    } else {
                        $response = $this->getAllProductions();
                    }
                }else{
                    $response = self::AuthFail();
                }
                break;
            case 'POST':
                if (Token::checkToken(Token::getToken("ADMIN_TOKEN"),"ADMIN_TOKEN")) {
                    $response = $this->createProductionFromRequest();
                }else{
                    $response = self::AuthFail();
                }
                break;
            case 'PUT':
                if (Token::checkToken(Token::getToken("ADMIN_TOKEN"),"ADMIN_TOKEN")) {
                    $response = $this->updateProductionFromRequest($this->productId);
                }else{
                    $response = self::AuthFail();
                }
                break;
            case 'DELETE':
                if (Token::checkToken(Token::getToken("ADMIN_TOKEN"),"ADMIN_TOKEN")) {
                    $response = $this->deleteProduction($this->productId);
                }else{
                    $response = self::AuthFail();
                }
                break;
            default:
                $response = $this->notFoundResponse();
                break;
        }
        header($response['status_code_header']);
        if ($response['body']) {
            echo $response['body'];
        }else{
            echo $response['body'];
        }
    }

    private function getAllProductions()
    {
        $productArr = [];
        $productTypes = [];
        $productsObject = new \stdClass();
        $x = 0;
        $y = 0;

        $results = $this->productionModel->findAll();

        foreach ($results as $result) {
            $productTypes = $this->productTypeModel->find($result['product_type_id']);
            if(sizeof($productTypes) > 0){
                $products = $this->productModel->find($productTypes[0]['product_id']);
                $productTypePrices = $this->productPriceModel->findByProductType($result['product_type_id']);

                $productsObject->production_id = $result["production_id"];
                $productsObject->quantity = $result["quantity"];
                $productsObject->in_date = $result["in_date"];
                $productsObject->product_id = $products[0]['product_id'];
                $productsObject->product_name = $products[0]['product_name'];
                $productsObject->product_type_id = $productTypes[0]['product_type_id'];
                $productsObject->product_type = $productTypes[0]['product_type'];
                $productsObject->product_image = $products[0]['product_image'];
                $productsObject->product_price = $productTypePrices[0]['price'] ?? null;


                $prodObjectJson = json_encode($productsObject);
                $productArr[$x] = json_decode($prodObjectJson);
            }
            $x +=1;

        }
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($productArr);
        return $response;
    }

    private function getProduction($id)
    {
        $result = $this->productionModel->find($id);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($result);
        return $response;
    }

    private function createProductionFromRequest()
    {
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);
        if (! $this->validateProduction($input)) {
            return $this->unprocessableEntityResponse();
        }
        $input['user_id'] = Session::get("user_id");

        if($this->productionModel->insert($input)) {
            $exists = $this->stockModel->find($input['product_type_id']);

            if(sizeof($exists) > 0){
                $input['quantity'] = $input['quantity'] + $exists[0]['quantity'];
                $this->stockModel->update($input);
            }else{
                $this->stockModel->insert($input);
            }
        }

        $response['status_code_header'] = 'HTTP/1.1 201 Created';
        $response['body'] = null;
        return $response;
    }
    private function updateProductionFromRequest($id)
    {
        $result = $this->productionModel->find($id);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);
        if (! $this->validateProduction($input)) {
            return $this->unprocessableEntityResponse();
        }
        $this->productionModel->update($id, $input);
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = null;
        return $response;
    }

    private function deleteProduction($id)
    {
        $result = $this->productionModel->find($id);
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);

        if (! $result) {
            return $this->notFoundResponse();
        }
        $exists = $this->stockModel->find($input['product_type_id']);

        if(sizeof($exists) > 0){
            $input['quantity'] = $exists[0]['quantity'] - $input['quantity'];
            $this->stockModel->update($input);
        }
        $this->productionModel->delete($id);
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = null;
        return $response;
    }

    private function validateProduction($input)
    {
        if (empty($input['operation_id'])) {
            return false;
        }
        if (empty($input['supplier_id'])) {
            return false;
        }
        if (empty($input['product_type_id'])) {
            return false;
        }
        if (empty($input['quantity'])) {
            return false;
        }
        return true;
    }

    private function unprocessableEntityResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 422 Unprocessable Entity';
        $response['body'] = json_encode([
            'error' => 'Invalid input'
        ]);
        return $response;
    }
    private function notFoundResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 404 Not Found';
        $response['body'] = json_encode(["status" => 404, "msg" =>"Not Found"]);
        return $response;
    }
    private function AuthFail()
    {
        $response['status_code_header'] = 'HTTP/1.1 203 Non-Authoritative Information!';
        $response['body'] = json_encode(["status" => 203, "msg" =>"Authication failed!"]);
        return $response;
    }
}
    ?>