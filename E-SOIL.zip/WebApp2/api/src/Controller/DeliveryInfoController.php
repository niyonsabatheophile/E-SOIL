<?php
namespace Src\Controller;

use Src\Models\OrderModel;
use Src\Models\DeliveryInfoModel;

class DeliveryInfoController {

    private $db;
    private $requestMethod;
    private $orderId;

    private $orderModel;
    private $deliveryInfoModel;

    public function __construct($db, $requestMethod, $orderId)
    {
        $this->db = $db;
        $this->requestMethod = $requestMethod;
        $this->orderId = $orderId;
        $this->orderModel = new OrderModel($db);
        $this->deliveryInfoModel = new DeliveryInfoModel($db);

    }

    public function processRequest()
    {
        switch ($this->requestMethod) {
            case 'GET':
                if ($this->orderId) {
                    $response = self::getDeliveryInf($this->orderId);
                } else {
                    $response = self::getAllDeliveryInf();
                };
                break;
            case 'POST':
                $response = self::createDeliveryInfFromRequest();
                break;
            case 'PUT':
                $response = self::updateDeliveryInfoFromRequest();
                break;
            case 'DELETE':
                $response = self::deleteDeliveryInf($this->orderId);
                break;
            default:
                $response = self::notFoundResponse();
                break;
        }
        header($response['status_code_header']);
        if ($response['body']) {
            echo $response['body'];
        }
    }

    private function getAllDeliveryInf()
    {
        $result = $this->deliveryInfoModel->findAll();
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($result);
        return $response;
    }

    private function getDeliveryInf($id)
    {
        $result = $this->deliveryInfoModel->findByOrderId($id);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($result);
        return $response;
    }

    private function createDeliveryInfFromRequest()
    {
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);
        if (! self::validateClient($input)) {
            return self::unprocessableEntityResponse();
        }
        // Check if client is registered
        if($this->deliveryInfoModel->findByOrderId($input['order_id'])) {
            $this->deliveryInfoModel->update($input);

            $response['status_code_header'] = 'HTTP/1.1 201 Alred exist';
            $response['body'] = null;
            return $response;
        }
        $this->deliveryInfoModel->insert($input);

        $response['status_code_header'] = 'HTTP/1.1 201 Created';
        $response['body'] = null;
        return $response;
    }

    private function updateDeliveryInfoFromRequest()
    {
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);

        $result = $this->deliveryInfoModel->find($input);
        if (! $result) {
            return $this->notFoundResponse();
        }
        if (! $this->validateClient($input)) {
            return $this->unprocessableEntityResponse();
        }
        $this->deliveryInfoModel->update($input);
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = null;
        return $response;
    }

    private function deleteUser($id)
    {
        $result = $this->deliveryInfoModel->find($id);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $this->deliveryInfoModel->delete($id);
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = null;
        return $response;
    }

    private function validateClient($input)
    {
        if (empty($input['order_id'])) {
            return false;
        }
        if (empty($input['country'])) {
            return false;
        }
        if (empty($input['province'])) {
            return false;
        }
        if (empty($input['city'])) {
            return false;
        }
        return true;
    }

    private function unprocessableEntityResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 422 Unprocessable Entity';
        $response['body'] = json_encode([
            'error' => 'Invalid input'
        ]);
        return $response;
    }

    private function notFoundResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 404 Not Found';
        $response['body'] = json_encode(["status" => 404, "msg" =>"Not Found"]);
        return $response;
    }
    private function AuthFail()
    {
        $response['status_code_header'] = 'HTTP/1.1 203 Non-Authoritative Information!';
        $response['body'] = json_encode(["status" => 203, "msg" =>"Authication failed!"]);
        return $response;
    }
}