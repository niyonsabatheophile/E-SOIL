<?php
namespace Src\Controller;

use Src\Models\AdminModel;
use Src\System\Session;
use Src\System\Token;
use Src\System\Encript;

class AdminController {

    private $db;
    private $requestMethod;
    private $adminId;
    private $action;

    private $adminModel;

    public function __construct($db, $requestMethod, $adminId)
    {
        $this->db = $db;
        $this->requestMethod = $requestMethod;
        $this->adminId = $adminId;
        $this->action = $action;
        $this->adminModel = new AdminModel($db);
    }

    public function processRequest()
    {
        switch ($this->requestMethod) {
            case 'GET':
                if (Token::checkToken(Token::getToken("ADMIN_TOKEN"),"ADMIN_TOKEN")) {
                    if (isset($this->adminId)) {
                        $response = self::getAdmin($this->adminId);
                    } else {
                        $response = self::getAllAdmins();
                    }
                }else{
                    $response = self::AuthFail();
                }
                break;
            case 'POST':
                if (Token::checkToken(Token::getToken("ADMIN_TOKEN"),"ADMIN_TOKEN")) {
                    if($this->action === "update_info"){
                        $response = self::updateAdminFromRequest($this->adminId);
                    }else if (($this->action === "change_password")){
                        $response = self::updateAdminPwdFromRequest($this->adminId);
                    }else{
                        $response = $this->notFoundResponse();
                    }
                }else{
                    $response = self::AuthFail();
                }
                break;
            case 'PUT':
                if (Token::checkToken(Token::getToken("ADMIN_TOKEN"),"ADMIN_TOKEN")) {
                    $response = self::updateAdminFromRequest($this->adminId);
                }else{
                    $response = self::AuthFail();
                }
                break;
            case 'DELETE':
                if (Token::checkToken(Token::getToken("ADMIN_TOKEN"),"ADMIN_TOKEN")) {
                    $response = self::deleteAdmin($this->adminId);
                }else{
                    $response = self::AuthFail();
                }
                break;
            default:
                $response = self::notFoundResponse();
                break;
        }
        header($response['status_code_header']);
        if ($response['body']) {
            echo $response['body'];
        }else{
            echo ($response['body']);
        }
    }

    private function getAllAdmins()
    {
        $result = $this->adminModel->findAll();
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($result);
        return $response;
    }

    private function getAdmin($id)
    {
        $result = $this->adminModel->find($id);
        if (! $result) {
            return self::notFoundResponse();
        }
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($result);
        return $response;
    }

    private function createAdminFromRequest()
    {
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);
        if (! self::validateAdmin($input)) {
            return self::unprocessableEntityResponse();
        }
        // Check if client is registered
        if($this->adminModel->findByEmailPhone($input['email'],$input['phone_number'])) {
            $response['status_code_header'] = 'HTTP/1.1 403 Alred exist';
            $response['body'] = json_encode([
            'msg' => 'Alred exist'
            ]);
            return $response;
        }
            $input['password'] = Encript::saltEncription($input['password']);
            $this->adminModel->insert($input);

            $response['status_code_header'] = 'HTTP/1.1 201 Created';
            $response['body'] = null;
            return $response;
    }

    private function updateAdminFromRequest($id)
    {
        $result = $this->adminModel->find($id);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);
        if (! self::validateAdmin($input)) {
            return self::unprocessableEntityResponse();
        }
        $this->adminModel->update($id, $input);
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = null;
        return $response;
    }

    private function updateAdminPwdFromRequest($id)
    {
        $result = $this->adminModel->find($id);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);
        if (empty($input['old_password'])) {
            return self::unprocessableEntityResponse();
        }
        // Check if Admin is registered
        $old_password = Encript::saltEncription($input['old_password']);

        if($result[0]["password"] != $old_password){
            $response['status_code_header'] = 'HTTP/1.1 400 Bad request';
            $response['body'] = json_encode(["msg" => "Old password is not correct"]);
            return $response;
        }
        if(empty($input['new_password'])){
            $response['status_code_header'] = 'HTTP/1.1 400 Bad request';
            $response['body'] = json_encode(["msg" => "New password is required"]);
            return $response;
        }
        $input['new_password'] = Encript::saltEncription($input['new_password']);

        $this->adminModel->updatePassword($id, $input);
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = null;
        return $response;
    }
    private function deleteAdmin($id)
    {
        $result = $this->adminModel->find($id);
        if (! $result) {
            return self::notFoundResponse();
        }
        $this->adminModel->delete($id);
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = null;
        return $response;
    }

    private function validateAdmin($input)
    {
        if (empty($input['fname'])) {
            return false;
        }
        if (empty($input['lname'])) {
            return false;
        }
        if (empty($input['email'])) {
            return false;
        }
        if (empty($input['phone_number'])) {
            return false;
        }
        return true;
    }

    private function unprocessableEntityResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 422 Unprocessable Entity';
        $response['body'] = json_encode([
            'error' => 'Invalid input'
        ]);
        return $response;
    }

    private function notFoundResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 404 Not Found';
        $response['body'] = json_encode(["status" => 404, "msg" =>"Not Found"]);
        return $response;
    }
    private function AuthFail()
    {
        $response['status_code_header'] = 'HTTP/1.1 203 Non-Authoritative Information!';
        $response['body'] = json_encode(["status" => 203, "msg" =>"Authotication failed!"]);
        return $response;
    }
}
?>