<?php
namespace Src\Controller;
use Src\System\UiidGeneretor;

use Src\Models\ProductTypeModel;
use Src\Models\ProductModel;
use Src\Models\OrderModel;
use Src\Models\ClientModel;
use Src\Models\ProductOrderedModel;
use Src\Models\ProductImageModel;
use Src\Models\ProductPriceModel;
use Src\Models\StockModel;
use Src\Models\DeliveryInfoModel;

class OrderController {

    private $db;
    private $requestMethod;
    private $orderId;
    private $status;
    private $uiidGeneretor;
    private $productImageModel;
    private $productPriceModel;
    private $productOrderedModel;
    private $orderModel;
    private $clientModel;
    private $productTypeModel;
    private $productModel;
    private $stockModel;
    private $deliveryInfoModel;

    public function __construct($db, $requestMethod, $orderId, $status)
    {
        $this->db = $db;
        $this->requestMethod = $requestMethod;
        $this->orderId = $orderId;
        $this->clientId = $orderId;
        $this->status = $status;
        $this->orderModel = new OrderModel($db);
        $this->clientModel = new ClientModel($db);
        $this->productOrderedModel = new ProductOrderedModel($db);
        $this->productTypeModel = new ProductTypeModel($db);
        $this->productModel = new ProductModel($db);
        $this->productPriceModel = new ProductPriceModel($db);
        $this->productImageModel = new ProductImageModel($db);
        $this->uiidGeneretor = new UiidGeneretor();
        $this->stockModel = new StockModel($db);
        $this->deliveryInfoModel = new DeliveryInfoModel($db);
    }

    public function processRequest()
    {
        switch ($this->requestMethod) {
            case 'GET':
                if($this->clientId && $this->status == 0) {
                    $response = self::getPeddingOrderByUserId($this->clientId);
                }elseif($this->clientId && $this->status == 1){
                    $response = self::getComplOrderByUserId($this->clientId);
                }elseif(!is_numeric($this->clientId) && $this->clientId != '') {
                    $response = self::getOrder($this->clientId);
                } else {
                    $response = self::getAllOrders();
                };
                break;
            case 'POST':
                $response = $this->createOrderFromRequest();
                break;
            case 'PUT':
                $response = $this->updateOrderFromRequest();
                break;
            case 'PATCH':
                $response = $this->deleteOrder();
                break;
            default:
                $response = $this->notFoundResponse();
                break;
        }
        header($response['status_code_header']);
        if ($response['body']) {
            echo $response['body'];
        }
    }

    private function getAllOrders()
    {
        $productArr = [];
        $productsObject = new \stdClass();
        $productTypesObject = new \stdClass();
        $x = 0;
        $y = 0;

        $clientOrders = $this->orderModel->findAll();
        if($clientOrders){
            foreach ($clientOrders as $clientOrder) {

                $orderedTypes = $this->productOrderedModel->findByOrder($clientOrder["order_id"]);
                $rlt_del_info = $this->deliveryInfoModel->findByOrderId($clientOrder["order_id"]);

                $productTypes = [];

                foreach ($orderedTypes as $orderedType) {
                    $productTypesObject->product_ordered_id = $orderedType['product_ordered_id'];

                    $productType = $this->productTypeModel->find($orderedType['product_type_id']);
                    $product_name = $this->productModel->find($productType[0]['product_id']);
                    $productPrice = $this->productPriceModel->findByProductType($productType[0]['product_type_id']);
                    $productImage = $this->productImageModel->findByProductType($productType[0]['product_type_id']);

                    $productTypesObject->product_name = $product_name[0]['product_name'];
                    $productTypesObject->price = $productPrice[0]['price'];
                    $productTypesObject->image = $productImage[0]['image'];
                    $productTypesObject->product_type = $productType[0]['product_type'];
                    $productTypesObject->quantity = $orderedType['quantity'];
                    $prodTypeObjectJson = json_encode($productTypesObject);
                    $productTypes[$y] = json_decode($prodTypeObjectJson);
                    
                    $y +=1;
                }
                $productsObject->orders = $clientOrder['order_id'];
                $productsObject->client_id = $clientOrder['client_id'];
                $productsObject->date_created = $clientOrder['ordered_date'];
                $productsObject->status = $clientOrder['status'];
                $productsObject->country = $rlt_del_info[0]['country'] ?? "-";
                $productsObject->province = $rlt_del_info[0]['province'] ?? "-";
                $productsObject->city = $rlt_del_info[0]['city'] ?? "-";
                $productsObject->products = $productTypes;
                $prodObjectJson = json_encode($productsObject);
                $productArr[$x] = json_decode($prodObjectJson);

                $x +=1;

            }
        }
        
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($productArr);
        return $response;
    }
    private function getPeddingOrderByUserId($clientId)
    {
        $productArr = [];
        $productTypes = [];
        $productsObject = new \stdClass();
        $productTypesObject = new \stdClass();
        $x = 0;
        $y = 0;

        $clientOrder = $this->orderModel->findByclientId($clientId,$this->status);
        if($clientOrder){
            $orderedTypes = $this->productOrderedModel->findByOrder($clientOrder[0]["order_id"]);
            foreach ($orderedTypes as $orderedType) {
                $productTypesObject->product_ordered_id = $orderedType['product_ordered_id'];
                $orderedProTypes = $this->productTypeModel->find($orderedType['product_type_id']);

                $orderedProduct = $this->productModel->find($orderedProTypes[0]['product_id']);
                $productPrice = $this->productPriceModel->findByProductType($orderedProTypes[0]['product_type_id']);
                $productImage = $this->productImageModel->findByProductType($orderedProTypes[0]['product_type_id']);

                $productTypesObject->product_name = $orderedProduct[0]['product_name'];
                $productTypesObject->product_type_id = $orderedProTypes[0]['product_type_id'];
                $productTypesObject->product_type = $orderedProTypes[0]['product_type'];
                $productTypesObject->price = $productPrice[0]['price'];
                $productTypesObject->image = $productImage[0]['image'];
                $productTypesObject->quantity = $orderedType['quantity'];

                $prodTypeObjectJson = json_encode($productTypesObject);
                $productTypes[$y] = json_decode($prodTypeObjectJson);
                
                $y +=1;
            }
            $productsObject->order_id = $clientOrder[0]['order_id'];
            $productsObject->products = $productTypes;
            $prodObjectJson = json_encode($productsObject);
            $productArr[$x] = json_decode($prodObjectJson);
        }
        
        $x +=1;

        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($productArr);
        return $response;
    }

    private function getComplOrderByUserId($clientId)
    {
        $productArr = [];
        $productTypes = [];
        $productsObject = new \stdClass();
        $productTypesObject = new \stdClass();
        $x = 0;
        $y = 0;

        $clientOrder = $this->orderModel->findByclientId($clientId,$this->status);
        if($clientOrder){
            $orderedTypes = $this->productOrderedModel->findByOrder($clientOrder[0]["order_id"]);
            foreach ($orderedTypes as $productType) {
                $productTypesObject->product_ordered_id = $productType['product_ordered_id'];
                $orderedType = $this->productTypeModel->find($productType['product_type_id']);

                $orderedProduct = $this->productModel->find($orderedType[0]['product_id']);
                $productPrice = $this->productPriceModel->findByProductType($orderedType[0]['product_type_id']);
                $productImage = $this->productImageModel->findByProductType($orderedType[0]['product_type_id']);

                $productTypesObject->product_name = $orderedProduct[0]['product_name'];
                $productTypesObject->product_type = $orderedType[0]['product_type'];
                $productTypesObject->price = $productPrice[0]['price'];
                $productTypesObject->image = $productImage[0]['image'];
                $productTypesObject->quantity = $productType['quantity'];

                $prodTypeObjectJson = json_encode($productTypesObject);
                $productTypes[$y] = json_decode($prodTypeObjectJson);
                
                $y +=1;
            }
            $productsObject->order_id = $clientOrder[0]['order_id'];
            $productsObject->products = $productTypes;
            $prodObjectJson = json_encode($productsObject);
            $productArr[$x] = json_decode($prodObjectJson);
        }
        
        $x +=1;

        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($productArr);
        return $response;
    }
    private function getOrder($id)
    {
        $result = $this->orderModel->find($id);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($result);
        return $response;
    }

    private function getProductTypeDetails() {
        $products = $this->orderModel->findAll();
        foreach ($products as $key => $product) {
            
        }
    }

    private function createOrderFromRequest()
    {
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);
        $input['order_id'] = $this->uiidGeneretor->guid();

        if (! self::validateOrder($input)) {
            return self::unprocessableEntityResponse();
        }
        $exists = $this->stockModel->find($input['product_type_id']);
        if(sizeof($exists) >= 0) {
            if(sizeof($exists) != 0){
                if($exists[0]['quantity'] < $input['quantity']){
                    $response['status_code_header'] = 'HTTP/1.1 403 Not Found';
                    $response['body'] = json_encode(["status" => 403, "msg" =>"Those quantities are out of stock!"]);
                    return $response;
                }                
            }else{
                $response['status_code_header'] = 'HTTP/1.1 403 Not Found';
                $response['body'] = json_encode(["status" => 403, "msg" =>"Those quantities are out of stock!"]);
                return $response;
            }
        }
        $clientOrdered = $this->orderModel->findByclientId($input['client_id'],0);

        if(sizeof($clientOrdered) > 0){

                $prodOrd = $this->productOrderedModel->findTypeOnOrder($clientOrdered[0]['order_id'],$input['product_type_id']);

                if(sizeof($prodOrd) > 0){
                    $response['status_code_header'] = 'HTTP/1.1 403 Not Found';
                    $response['body'] = json_encode(["status" => 403, "msg" =>"Already added on cart"]);
                    return $response;
                }else{
                    $this->productOrderedModel->insert(["order_id" =>$clientOrdered[0]['order_id'], "product_type_id" =>$input['product_type_id'], "quantity" => $input['quantity']]);
                    $response['status_code_header'] = 'HTTP/1.1 201 Created';
                    $response['body'] = null;
                    return $response;
                }

        }else{
            if($this->orderModel->insert($input)){
                $this->productOrderedModel->insert(["order_id" =>$input['order_id'], "product_type_id" =>$input['product_type_id'], "quantity" => $input['quantity']]);
            }
        }
        $response['status_code_header'] = 'HTTP/1.1 201 Created';
        $response['body'] = null;
        return $response;
    }
    private function updateOrderFromRequest()
    {
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);

        $result = $this->orderModel->findByOrderAndClient($input['order_id'],$input['client_id']);
        if (! $result) {
            return $this->notFoundResponse();
        }
        if (! $this->validateOrder($input)) {
            return $this->unprocessableEntityResponse();
        }
        $this->productOrderedModel->update($input);
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = null;
        return $response;
    }

    private function deleteOrder()
    {
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);
        $result = $this->orderModel->find($input['order_id']);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $this->orderModel->delete($input['order_id']);
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = null;
        return $response;
    }

    private function validateOrder($input)
    {
        if (empty($input['order_id'])) {
            return false;
        }
        if (empty($input['client_id'])) {
            return false;
        }
        // if (empty($input['product_type_id'])) {
        //     return false;
        // }
        if (empty($input['quantity'])) {
            return false;
        }
        return true;
    }

    private function unprocessableEntityResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 422 Unprocessable Entity';
        $response['body'] = json_encode([
            'error' => 'Invalid input'
        ]);
        return $response;
    }
    private function notFoundResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 404 Not Found';
        $response['body'] = json_encode(["status" => 404, "msg" =>"Not Found"]);
        return $response;
    }
}
?>