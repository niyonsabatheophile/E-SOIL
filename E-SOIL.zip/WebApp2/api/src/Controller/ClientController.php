<?php
namespace Src\Controller;

use Src\Models\ClientModel;
use Src\System\Session;
use Src\System\Token;
use Src\System\Encript;

class ClientController {

    private $db;
    private $requestMethod;
    private $clientId;

    private $clientModel;
    private $action;
    public function __construct($db, $requestMethod, $clientId, $action)
    {
        $this->db = $db;
        $this->requestMethod = $requestMethod;
        $this->clientId = $clientId;
        $this->action = $action;
        $this->clientModel = new ClientModel($db);
    }

    public function processRequest()
    {
        switch ($this->requestMethod) {
            case 'GET':
                    if (isset($this->clientId)) {
                        $response = $this->getClient($this->clientId);
                    } else {
                        //if (Token::checkToken(Token::getToken("ADMIN_TOKEN"),"ADMIN_TOKEN")) {
                            $response = $this->getAllClients();
                        // }else{
                        //     $response = $this->AuthFail();
                        // }
                    }
                break;
            case 'POST':
                $response = $this->createClientFromRequest();
                break;
            case 'PUT':
                if (Token::checkToken(Token::getToken("ADMIN_TOKEN"),"ADMIN_TOKEN") || Token::checkToken(Token::getToken("USER_TOKEN"),"USER_TOKEN")) {
                    if($this->action === "update_info"){
                        $response = $this->updateUserFromRequest($this->clientId);
                    }else if (($this->action === "change_password")){
                        $response = self::changeUserFromRequest($this->clientId);
                    }else{
                        $response = $this->notFoundResponse();
                    }
                }else{
                    $response = $this->AuthFail();
                }
                break;
            case 'DELETE':
                if (Token::checkToken(Token::getToken("ADMIN_TOKEN"),"ADMIN_TOKEN") || Token::checkToken(Token::getToken("USER_TOKEN"),"USER_TOKEN")) {
                    $response = $this->deleteUser($this->clientId);
                }else{
                    $response = $this->AuthFail();
                }
                break;
            default:
                $response = $this->notFoundResponse();
                break;
        }
        header($response['status_code_header']);
        if ($response['body']) {
            echo $response['body'];
        }
    }

    private function getAllClients()
    {
        $result = $this->clientModel->findAll();
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($result);
        return $response;
    }

    private function getClient($id)
    {
        $result = $this->clientModel->find($id);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($result);
        return $response;
    }

    private function createClientFromRequest()
    {
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);
        if (! self::validateClient($input)) {
            return self::unprocessableEntityResponse();
        }
        // Check if client is registered
        if($this->clientModel->findByEmail($input['email'])) {
            $response['status_code_header'] = 'HTTP/1.1 403 Alred exist';
            $response['body'] = json_encode([
            'msg' => 'Alred exist'
            ]);
            return $response;
        }
            $input['password'] = Encript::saltEncription($input['password']);
            $this->clientModel->insert($input);

            $response['status_code_header'] = 'HTTP/1.1 201 Created';
            $response['body'] = null;
            return $response;
    }

    private function updateUserFromRequest($id)
    {
        $result = $this->clientModel->find($id);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);
        // Check if client is registered
        // if($this->clientModel->findByEmail($input['email'])) {
        //     $response['status_code_header'] = 'HTTP/1.1 403 Already exist';
        //     $response['body'] = json_encode([
        //     'msg' => 'Already exist'
        //     ]);
        //     return $response;
        // }
        if (! $this->validateClient($input)) {
            return $this->unprocessableEntityResponse();
        }
        $this->clientModel->update($id, $input);
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = null;
        return $response;
    }
    private function changeUserFromRequest($id)
    {
        $result = $this->clientModel->find($id);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);
        // Check if client is registered
        $old_password = Encript::saltEncription($input['old_password']);

        if($result[0]["password"] != $old_password){
            $response['status_code_header'] = 'HTTP/1.1 400 OK';
            $response['body'] = json_encode(["msg" => "Old password is not correct"]);
            return $response;
        }
        if($input['new_password'] == ''){
            $response['status_code_header'] = 'HTTP/1.1 400 OK';
            $response['body'] = json_encode(["msg" => "New password is required"]);
            return $response;
        }
        $input['new_password'] = Encript::saltEncription($input['new_password']);

        $this->clientModel->updatePassword($id, $input);
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = null;
        return $response;
    }
    private function deleteUser($id)
    {
        $result = $this->clientModel->find($id);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $this->clientModel->delete($id);
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = null;
        return $response;
    }

    private function validateClient($input)
    {
        if (empty($input['fname'])) {
            return false;
        }
        if (empty($input['lname'])) {
            return false;
        }
        if (empty($input['gender'])) {
            return false;
        }
        if (empty($input['email'])) {
            return false;
        }
        if (empty($input['phone_number'])) {
            return false;
        }
        return true;
    }

    private function unprocessableEntityResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 422 Unprocessable Entity';
        $response['body'] = json_encode([
            'error' => 'Invalid input'
        ]);
        return $response;
    }

    private function notFoundResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 404 Not Found';
        $response['body'] = json_encode(["status" => 404, "msg" =>"Not Found"]);
        return $response;
    }

    private function AuthFail()
    {
        $response['status_code_header'] = 'HTTP/1.1 203 Non-Authoritative Information!';
        $response['body'] = json_encode(["status" => 203, "msg" =>"Authotication failed!"]);
        return $response;
    }
}