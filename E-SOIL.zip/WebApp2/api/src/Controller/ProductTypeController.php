<?php
namespace Src\Controller;
use Src\System\UiidGeneretor;

use Src\Models\ProductTypeModel;
use Src\Models\ProductModel;
use Src\Models\ProductPriceModel;
use Src\Models\ProductImageModel;

class ProductTypeController {

    private $db;
    private $requestMethod;
    private $productTypeId;
    private $proId;
    private $action;

    #Object declaration
    private $productTypeModel;
    private $productModel;
    private $productPriceModel;
    private $productImageModel;
    private $uiidGeneretor;

    public function __construct($db, $requestMethod, $productTypeId,$proId, $action)
    {
        $this->db = $db;
        $this->proId = $proId;
        $this->action = $action;
        $this->requestMethod = $requestMethod;
        $this->productTypeId = $productTypeId;

        $this->productTypeModel = new ProductTypeModel($db);
        $this->productModel = new ProductModel($db);
        $this->productPriceModel = new ProductPriceModel($db);
        $this->productImageModel = new ProductImageModel($db);
        $this->uiidGeneretor = new UiidGeneretor();
    }

    public function processRequest()
    {
        switch ($this->requestMethod) {
            case 'GET':
                if ($this->productTypeId) {
                    if($this->productTypeId === 'pid' && $this->proId != ''){
                        $response = self::getTypeByProId($this->proId);
                    }elseif($this->productTypeId !== 'details') {
                        $response = $this->getProductType($this->productTypeId);
                    }else{
                        $response = $this->getProductTypeDetails($this->productTypeId);
                    }
                } else {
                    $response = $this->getProductTypeDetails();
                };
                break;
            case 'POST':
                if ($this->action == 'update') {
                    $response = $this->updateProductFromRequest();
                }else{
                    $response = $this->createProductFromRequest();
                }
                break;
            case 'PUT':
                $response = $this->updateProductFromRequest();
                break;
            case 'DELETE':
                $response = $this->deleteProduct($this->productTypeId);
                break;
            default:
                $response = $this->notFoundResponse();
                break;
        }
        header($response['status_code_header']);
        if ($response['body']) {
            echo ($response['body']);
        }
    }

    private function getAllProductTypes()
    {
        $result = $this->productTypeModel->findAll();
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($result);
        return $response;
    }

    private function getProductType($id)
    {
        $productTypesArr = [];
        $productsObject = new \stdClass();

        $productType = $this->productTypeModel->find($id);
        if (! $productType) {
            return $this->notFoundResponse();
        }
        $productsData = $this->productModel->find($productType[0]['product_id']);
        $productTypePrices = $this->productPriceModel->findByProductType($productType[0]['product_type_id']);
        $productTypeImgs = $this->productImageModel->findByProductType($productType[0]['product_type_id']);

        $productsObject->product_id = $productsData[0]['product_id'];
        $productsObject->product_name = $productsData[0]['product_name'];
        $productsObject->product_type_id = $productType[0]['product_type_id'];
        $productsObject->product_type = $productType[0]['product_type'];
        $productsObject->product_description = $productType[0]['product_description'];
        $productsObject->product_price = $productTypePrices[0]['price'] ?? null;
        $productsObject->product_image = $productTypeImgs ?? null;
        $prodObjectJson = json_encode($productsObject);
        $productTypesArr = json_decode($prodObjectJson);
        
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($productTypesArr);
        return $response;
    }
    // Get all product type details
    private function getProductTypeDetails() 
    {
        $productTypesArr = [];
        $productsObject = new \stdClass();
        $x = 0;

        $productTypes = $this->productTypeModel->findAll();
        foreach ($productTypes as $productType) {
            $productTypePrices = $this->productPriceModel->findByProductType($productType['product_type_id']);
            $productTypeImgs = $this->productImageModel->findByProductType($productType['product_type_id']);

            $productsObject->product_type_id = $productType['product_type_id'];
            $productsObject->product_type = $productType['product_type'];
            $productsObject->product_description = $productType['product_description'];
            $productsObject->product_price = $productTypePrices[0]['price'] ?? null;
            $productsObject->product_image = $productTypeImgs ?? null;
            $prodObjectJson = json_encode($productsObject);
            $productTypesArr[$x] = json_decode($prodObjectJson);
            
            $x +=1;

        }
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($productTypesArr);
        return $response;
    }
    private function getTypeByProId($proId) 
    {
        $result = $this->productTypeModel->findProdTypeByProdId($proId);
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($result);
        return $response;
    }
    private function createProductFromRequest()
    {
        // $input = (array) json_decode(file_get_contents('php://input'), TRUE);
        // $msg = ["product_type"=> $_POST['product_type'],"image" => $_FILES["image"]["name"]];
        if(isset($_FILES) && !empty($_FILES['image']['name'])) {
            $target_dir = 'public/product-type-image/';
            $product_img = time().basename($_FILES['image']['name']);
            $fileToMove = $target_dir.$product_img;
        }else{
            return $this->unprocessableEntityResponse();
        }

        $input['product_type_id'] = $this->uiidGeneretor->guid();

        $input['product_id'] = $_POST['product_id'];
        $input['product_type'] = $_POST['product_type'];
        $input['price'] = $_POST['price'];
        $input['typeDescr'] = $_POST['typeDescr'];
        $input['image'] = $fileToMove;

        if (! $this->validateProduct($input)) {
            return $this->unprocessableEntityResponse();
        }
        // Chech if product is already exist
        $result = $this->productModel->find($input['product_id']);
        if (! $result) {
            return $this->notFoundResponse();
        }
        // Chech if product price is already set
        $result = $this->productPriceModel->findByProductType($input['product_type_id']);
        if ($result) {
            $result = $this->productPriceModel->updatePrice($result[0]['product_price_id']);
            if($result){
                $this->productPriceModel->insert($input);
            }
        }else{
            $this->productPriceModel->insert($input);
        }
        // Check if product image iserted
        
        $result = $this->productImageModel->insert($input);
        if(! $result){

        }
        // Chech if product image is already set
        $result = $this->productTypeModel->find($input['product_type_id']);
        if(! $result){
            move_uploaded_file($_FILES["image"]["tmp_name"], $fileToMove);
            $this->productTypeModel->insert($input);
        }
        $response['status_code_header'] = 'HTTP/1.1 201 Created';
        $response['body'] = null;
        return $response;
    }
    private function updateProductFromRequest()
    {
        // $input = (array) json_decode(file_get_contents('php://input'), TRUE);
        $fileToMove = '';

        $result = $this->productTypeModel->find($_POST['product_type_id']);
        if (! $result) {
            return $this->notFoundResponse();
        }
        if(isset($_FILES) && !empty($_FILES['image']['name'])) {
            $target_dir = 'public/product-type-image/';
            $product_img = time().basename($_FILES['image']['name']);
            $fileToMove = $target_dir.$product_img;
        }

        $input['product_type_id'] = $_POST['product_type_id'];
        $input['product_id'] = $_POST['product_id'];
        $input['product_type'] = $_POST['product_type'];
        $input['price'] = $_POST['price'];
        $input['typeDescr'] = $_POST['typeDescr'];
        $input['image'] = $fileToMove;

        $id = $input['product_type_id'];

        // Chech if product price is already set
        $result = $this->productPriceModel->findByProductType($id);
        if ($result) {
            $result = $this->productPriceModel->update($result[0]['product_price_id'],$input);
        }
        $image_exist = $this->productImageModel->findByProductType($id);
        if(sizeof($image_exist) > 0 && !empty($fileToMove)){
            move_uploaded_file($_FILES["image"]["tmp_name"], $fileToMove);
            $result = $this->productImageModel->update($image_exist[0]['product_image_id'],$input);
        }
        $this->productTypeModel->update($input);
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($image_exist);
        return $response;
    }

    private function deleteProduct($id)
    {
        $result = $this->productTypeModel->find($id);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $this->productTypeModel->delete($id);
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = null;
        return $response;
    }

    private function validateProduct($input)
    {
        if (empty($input['product_type_id'])) {
            return false;
        }
        if (empty($input['product_type'])) {
            return false;
        }
        if (empty($input['product_id'])) {
            return false;
        }
        if (empty($input['image'])) {
            return false;
        }
        if (empty($input['price'])) {
            return false;
        }
        return true;
    }
    private  function validateProUpdate($input)
    {
        if (empty($input['product_type_id'])) {
            return false;
        }
        if (empty($input['product_type'])) {
            return false;
        }
        if (empty($input['product_id'])) {
            return false;
        }
        if (empty($input['price'])) {
            return false;
        }
        return true;
    }
    private function unprocessableEntityResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 422 Unprocessable Entity';
        $response['body'] = json_encode([
            'error' => 'Invalid input'
        ]);
        return $response;
    }
    private function notFoundResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 404 Not Found';
        $response['body'] = json_encode(["status" => 404, "msg" =>"Not Found"]);
        return $response;
    }
}
    ?>