<?php
namespace Src\Models;

class ProductOrderedModel {
    private $db = null;

    public function __construct($db) {
        $this->db = $db;
    }

    public function findAll() {
        $statement = "
        SELECT *
            FROM 
        products_ordered WHERE status = 1;
        ";
        try {
            $statement = $this->db->query($statement);
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;

        } catch (\PDOException $e) {
            exit($e->getMessage());
        }
    }

    public function find($id)
    {
        $statement = "
            SELECT 
                *
            FROM
                products_ordered
            WHERE product_ordered_id = ? AND status = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($id,1));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function findByOrder($order_id)
    {
        $statement = "
            SELECT 
                *
            FROM
                products_ordered
            WHERE order_id = ? AND status = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($order_id,1));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
    public function findTypeOnOrder($order_id,$product_type_id)
    {
        $statement = "
            SELECT 
                *
            FROM
                products_ordered
            WHERE order_id = ? AND product_type_id = ?  AND status = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($order_id,$product_type_id,1));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
    public function insert(Array $input)
    {
        $statement = "
            INSERT INTO products_ordered 
                (order_id, product_type_id,quantity)
            VALUES
                (:order_id, :product_type_id,:quantity);
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':order_id' => $input['order_id'],
                ':product_type_id'  => $input['product_type_id'],
                ':quantity'  => $input['quantity']
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function update(Array $input)
    {
        $statement = "
            UPDATE products_ordered
            SET 
                quantity  = :quantity
            WHERE product_ordered_id = :product_ordered_id AND order_id = :order_id AND status = :status;
        ";
        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':product_ordered_id' => $input['product_ordered_id'],
                ':order_id' => $input['order_id'],
                ':quantity' => $input['quantity'],
                ':status' => 1
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function delete($product_ordered_id)
    {
        $statement = "
            DELETE 
            FROM 
                products_ordered
            WHERE 
                product_ordered_id = :product_ordered_id;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array('product_ordered_id' => $product_ordered_id));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

}
?>