<?php
namespace Src\Models;

class ProductImageModel {
    private $db = null;

    public function __construct($db) {
        $this->db = $db;
    }

    public function findAll() {
        $statement = "
        SELECT *
            FROM 
        product_images WHERE status = 1
        ";
        try {
            $statement = $this->db->query($statement);
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;

        } catch (\PDOException $e) {
            exit($e->getMessage());
        }
    }

    public function find($product_image_id)
    {
        $statement = "
            SELECT 
                *
            FROM
                product_images
            WHERE product_image_id = ? AND status = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($product_image_id,1));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function findByProductType($product_type_id)
    {
        $statement = "
            SELECT 
                *
            FROM
                product_images
            WHERE product_type_id = ? AND status = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($product_type_id,1));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function insert(Array $input)
    {
        $statement = "
            INSERT INTO product_images 
                (product_type_id, image)
            VALUES
                (:product_type_id, :image);
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':product_type_id'  => $input['product_type_id'],
                ':image' => $input['image']
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function update($product_image_id, Array $input)
    {
        $statement = "
            UPDATE product_images
            SET 
                image = :image
            WHERE product_image_id = :product_image_id;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':product_image_id' => $product_image_id,
                ':image'  => $input['image'],
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function delete($product_image_id)
    {
        $statement = "
            DELETE FROM product_images
            WHERE product_image_id = :product_image_id;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array('product_image_id' => $product_image_id));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

}
?>