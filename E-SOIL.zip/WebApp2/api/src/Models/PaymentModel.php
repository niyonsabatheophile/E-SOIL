<?php
namespace Src\Models;

class PaymentModel {
   private $db = null;

    public function __construct($db) {
        $this->db = $db;
    }

    public function findAll() {
        $statement = "
        SELECT *
            FROM 
        payments WHERE status = 1
        ";
        try {
            $statement = $this->db->query($statement);
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;

        } catch (\PDOException $e) {
            exit($e->getMessage());
        }
    }

    public function find($_id)
    {
        $statement = "
            SELECT 
                *
            FROM
                payments
            WHERE payment_id = ? AND status = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($id,1));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
    public function findBytransId(array $input)
    {
        $statement = "
            SELECT 
                *
            FROM
                payments
            WHERE walletTransactionId = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($input['walletTransactionId']));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
    public function findByWalletTransId(array $input)
    {
        $statement = "
            SELECT 
                *
            FROM
                payments
            WHERE walletTransactionId = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($input['walletTransactionId']));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
    public function findByOrder($_id)
    {
        $statement = "
            SELECT 
                *
            FROM
                payments
            WHERE order_id = ? AND status = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($id,1));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
    public function insert(Array $input)
    {
        $statement = "
            INSERT INTO
            payments 
                (statusDescription, spTransactionId, walletTransactionId, chargedCommission, currency, paidAmount, transactionId, statusCode, order_id, client_id, status)
            VALUES
                (:statusDescription, :spTransactionId, :walletTransactionId, :chargedCommission, :currency, :paidAmount, :transactionId, :statusCode, :order_id, :client_id, :status);
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ":statusDescription" => $input['statusDescription'] ?? null,
                ":spTransactionId" => $input['spTransactionId'] ?? null, 
                ":walletTransactionId" => $input['transactionId'],
                ":chargedCommission" => $input['chargedCommission'] ?? null,
                ":currency" => $input['currency'] ?? 0,
                ":paidAmount" => $input['paidAmount'] ?? 0,
                ":transactionId" => $input['walletTransactionId'] ?? null,
                ":statusCode" => $input['statusCode'] ?? null,
                ":order_id" => $input['order_id'],
                ":client_id" => $input['client_id'],
                ":status" => $input['status']
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function update(Array $input)
    {
        $statement = "
            UPDATE 
                payments
            SET 
                statusDescription = :statusDescription,
                spTransactionId = :spTransactionId,
                chargedCommission = :chargedCommission,
                currency = :currency,
                paidAmount = :paidAmount,
                transactionId = :transactionId,
                statusCode = :statusCode,
                status = :status
            WHERE 
                walletTransactionId = :walletTransactionId;
        ";
        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ":statusDescription" => $input['statusDescription'],
                ":spTransactionId" => $input['spTransactionId'], 
                ":walletTransactionId" => $input['walletTransactionId'],
                ":chargedCommission" => $input['chargedCommission'],
                ":currency" => $input['currency'],
                ":paidAmount" => $input['paidAmount'],
                ":transactionId" => $input['transactionId'],
                ":statusCode" => $input['statusCode'],
                ":status" => $input['status']
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function delete($supplier_id)
    {
        $statement = "
            DELETE FROM payments
            WHERE 
                supplier_id = :supplier_id;
        ";
        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array('supplier_id' => $supplier_id));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    } 
}

?>