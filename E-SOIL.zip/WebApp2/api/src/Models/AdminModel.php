<?php
namespace Src\Models;

class AdminModel {

    private $db = null;

    public function __construct($db)
    {
      $this->db = $db;
    }

    public function findAll()
    {
      $statement = "
            SELECT 
              user_id,fname,lname,phone_number,email,status
            FROM
              admins 
            WHERE 
                status = 1;
      ";

      try {
          $statement = $this->db->query($statement);
          $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
          return $result;
      } catch (\PDOException $e) {
          exit($e->getMessage());
      }
    }
    public function find($id)
    {
        $statement = "
            SELECT 
                *
            FROM
                admins
            WHERE 
                user_id = ? AND status = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($id,1));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
    public function findByEmail($email)
    {
        $statement = "
            SELECT 
                *
            FROM
                admins
            WHERE (email = ? ) AND status = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($email,1));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function findByPhone($phone_number)
    {
        $statement = "
            SELECT 
                *
            FROM
                admins
            WHERE phone_number = ? AND status = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($phone_number,1));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function findByEmailPhone($email = null, $phone_number = null)
    {
        $statement = "
            SELECT 
                *
            FROM
                admins
            WHERE (email = ? || phone_number = ? )AND status = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($email,$phone_number,1));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function insert(Array $input)
    {
        $statement = "
            INSERT INTO admins 
                (fname, lname, phone_number, email, password)
            VALUES
                (:fname, :lname, :phone_number, :email, :password);
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':fname' => $input['fname'],
                ':lname'  => $input['lname'],
                ':phone_number' => $input['phone_number'],
                ':email' => $input['email'],
                ':password' => $input['password']
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function update($id, Array $input)
    {
        $statement = "
            UPDATE admins
            SET 
                fname = :fname,
                lname  = :lname,
                email = :email,
                phone_number = :phone_number
            WHERE user_id = :id AND status = :status;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':id' => (int) $id,
                ':fname' => $input['fname'],
                ':lname'  => $input['lname'],
                ':email' => $input['email'],
                ':phone_number' => $input['phone_number'],
                ':status' => 1
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
   public function updatePassword($id, Array $input)
    {
        $statement = "
            UPDATE 
                admins
            SET 
                password = :password
            WHERE 
                user_id = :user_id AND status = :status;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':password' => $input['new_password'],
                ':user_id' => $id,
                'status' => 1
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
    public function delete($id)
    {
        $statement = "
            UPDATE 
                admins
            SET 
                status = 0
            WHERE user_id = :id AND status = :status;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(':id' => $id,':status' =>1));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

}
?>