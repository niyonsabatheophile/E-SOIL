<?php
namespace Src\Models;

class ProductPriceModel {
    private $db = null;

    public function __construct($db) {
        $this->db = $db;
    }

    public function findAll() {
        $statement = "
        SELECT *
            FROM 
        product_prices WHERE status = 1
        ";
        try {
            $statement = $this->db->query($statement);
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;

        } catch (\PDOException $e) {
            exit($e->getMessage());
        }
    }

    public function find($product_price_id)
    {
        $statement = "
            SELECT 
                *
            FROM
                product_prices
            WHERE product_price_id = ? AND status = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($product_price_id,1));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function findByProductType($product_type_id)
    {
        $statement = "
            SELECT 
                *
            FROM
                product_prices
            WHERE product_type_id = ? AND status = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($product_type_id,1));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function insert(Array $input)
    {
        $statement = "
            INSERT INTO product_prices 
                (product_type_id, price)
            VALUES
                (:product_type_id, :price);
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':product_type_id'  => $input['product_type_id'],
                ':price' => $input['price']
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function update($product_price_id, Array $input)
    {
        $statement = "
            UPDATE product_prices
            SET 
                price = :price
            WHERE product_price_id = :product_price_id AND status = 1;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':product_price_id' => $product_price_id,
                ':price'  => $input['price'],
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
    public function updatePrice($product_price_id)
    {
        $statement = "
            UPDATE product_prices
            SET 
                status = :status
            WHERE product_price_id = :product_price_id
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
               ':product_price_id' => $product_price_id,
               ':status' => 0
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function delete($product_price_id)
    {
        $statement = "
            DELETE FROM product_prices
            WHERE product_price_id = :product_price_id;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array('product_price_id' => $product_price_id));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

}
?>