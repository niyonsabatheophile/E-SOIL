<?php
namespace Src\Models;

class OrderModel {
    private $db = null;

    public function __construct($db) {
        $this->db = $db;
    }

    public function findAll() {
        $statement = "
        SELECT *
            FROM 
        orders WHERE status != 2;
        ";
        try {
            $statement = $this->db->query($statement);
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;

        } catch (\PDOException $e) {
            exit($e->getMessage());
        }
    }

    public function find($id)
    {
        $statement = "
            SELECT 
                *
            FROM
                orders
            WHERE order_id = ? AND status = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($id,0));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
    public function findByclientId($id,$status)
    {
        if($status == 0) {
            $statement = "
                SELECT 
                    *
                FROM
                    orders
                WHERE client_id = ? AND status = ?;
            ";
        }else{
            $statement = "
                SELECT 
                    *
                FROM
                    orders
                WHERE client_id = ? AND status = ?;
            ";
        }

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($id,$status));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
    public function findByOrderAndClient($order_id,$client_id)
    {
        $statement = "
            SELECT 
                *
            FROM
                orders
            WHERE order_id = ? AND client_id = ? AND status = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($order_id,$client_id,0));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
    public function findPending()
    {
        $statement = "
            SELECT 
                *
            FROM
                orders
            WHERE status = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(0));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
    public function findComplete()
    {
        $statement = "
            SELECT 
                *
            FROM
                orders
            WHERE status = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(1));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
    public function insert(Array $input)
    {
        $statement = "
            INSERT INTO orders 
                (order_id, client_id)
            VALUES
                (:order_id, :client_id);
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':order_id' => $input['order_id'],
                ':client_id'  => $input['client_id']
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function update(Array $orderData)
    {
        $statement = "
            UPDATE orders
            SET 
                status = 1
            WHERE order_id = :order_id AND client_id = :client_id ;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':order_id' => $orderData[0]['order_id'],
                ':client_id' => $orderData[0]['client_id']
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function delete($order_id)
    {
        $statement = "
            UPDATE orders
            SET 
                status = 2
            WHERE order_id = :order_id;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array('order_id' => $order_id));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

}
?>