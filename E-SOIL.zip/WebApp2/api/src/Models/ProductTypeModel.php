<?php
namespace Src\Models;

class ProductTypeModel {
    private $db = null;

    public function __construct($db) {
        $this->db = $db;
    }

    public function findAll() {
        $statement = "
        SELECT *
            FROM 
        product_types WHERE status = 1
        ";
        try {
            $statement = $this->db->query($statement);
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;

        } catch (\PDOException $e) {
            exit($e->getMessage());
        }
    }

    public function find($product_type_id)
    {
        $statement = "
            SELECT 
                *
            FROM
                product_types
            WHERE product_type_id = ? AND status = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($product_type_id,1));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
    
    public function findProdTypeByProdId($product_id)
    {
        $statement = "
            SELECT 
                *
            FROM
                product_types
            WHERE product_id = ? AND status = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($product_id,1));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
    public function insert(Array $input)
    {
        $statement = "
            INSERT INTO product_types 
                (product_type_id, product_type, product_id, product_description)
            VALUES
                (:product_type_id, :product_type, :product_id, :product_description);
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':product_type_id' => $input['product_type_id'],
                ':product_type'  => $input['product_type'],
                ':product_id' => $input['product_id'],
                ':product_description' => $input['typeDescr']
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function update(Array $input)
    {
        $statement = "
            UPDATE product_types
            SET 
                product_type = :product_type,
                product_description = :product_description
            WHERE product_type_id = :product_type_id;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':product_type_id' => $input['product_type_id'],
                ':product_type' => $input['product_type'],
                ':product_description' => $input['typeDescr']
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function delete($product_type_id)
    {
        $statement = "
            UPDATE
                product_types
            SET 
                status = 0
            WHERE 
                product_type_id = :product_type_id;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array('product_type_id' => $product_type_id));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

}
?>