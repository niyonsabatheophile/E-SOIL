<?php
namespace Src\Models;

class ProductModel {
    private $db = null;

    public function __construct($db) {
        $this->db = $db;
    }

    public function findAll() {
        $statement = "
        SELECT *
            FROM 
        products WHERE status = 1;
        ";
        try {
            $statement = $this->db->query($statement);
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;

        } catch (\PDOException $e) {
            exit($e->getMessage());
        }
    }

    public function find($id)
    {
        $statement = "
            SELECT 
                *
            FROM
                products
            WHERE product_id = ? AND status = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($id,1));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
public function insert(Array $input)
    {
        $statement = "
            INSERT INTO products 
                (product_id, product_name, product_image)
            VALUES
                (:product_id, :product_name, :product_image);
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':product_id' => $input['product_id'],
                ':product_name'  => $input['product_name'],
                ':product_image' => $input['product_image'],
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

public function update(Array $input)
    {
        $statement = "
            UPDATE 
                products
            SET 
                product_name = :product_name,
                product_image  = :product_image
            WHERE 
                product_id = :product_id AND status = 1;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':product_id' => $input['product_id'],
                ':product_name' => $input['product_name'],
                ':product_image'  => $input['product_image']
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
    public function updateName(Array $input)
    {
        $statement = "
            UPDATE 
                products
            SET 
                product_name = :product_name
            WHERE 
                product_id = :product_id AND status = 1;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':product_id' => $input['product_id'],
                ':product_name' => $input['product_name']
           ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function delete($product_id)
    {
        $statement = "
            UPDATE 
                products
            SET 
                status = 0
            WHERE 
                product_id = :product_id;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(':product_id' => $product_id));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

}
?>