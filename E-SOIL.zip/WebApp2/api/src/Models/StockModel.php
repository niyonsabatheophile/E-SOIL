<?php
namespace Src\Models;

class StockModel {
    private $db = null;

    public function __construct($db) {
        $this->db = $db;
    }

    public function findAll() {
        $statement = "
        SELECT *
            FROM 
        current_stock;
        ";
        try {
            $statement = $this->db->query($statement);
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;

        } catch (\PDOException $e) {
            exit($e->getMessage());
        }
    }

    public function find($id)
    {
        $statement = "
            SELECT 
                *
            FROM
                current_stock
            WHERE product_type_id = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($id));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
    public function insert(Array $input)
    {
        $statement = "
            INSERT INTO current_stock 
                (product_type_id, quantity)
            VALUES
                (:product_type_id, :quantity);
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':product_type_id' => $input['product_type_id'],
                ':quantity'  => $input['quantity']
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function update(Array $input)
    {
        $statement = "
            UPDATE current_stock
            SET 
                quantity = :quantity
            WHERE product_type_id = :product_type_id;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':product_type_id' => $input['product_type_id'],
                ':quantity' => $input['quantity']
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function delete($product_type_id)
    {
        $statement = "
            UPDATE current_stock
            SET 
                status = 2
            WHERE product_type_id = :product_type_id;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array('product_type_id' => $product_type_id));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

}
?>