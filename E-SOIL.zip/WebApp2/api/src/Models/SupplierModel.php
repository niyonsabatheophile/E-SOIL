<?php
namespace Src\Models;

class SupplierModel {
    private $db = null;

    public function __construct($db) {
        $this->db = $db;
    }

    public function findAll() {
        $statement = "
        SELECT *
            FROM 
        suppliers WHERE status = 1
        ";
        try {
            $statement = $this->db->query($statement);
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;

        } catch (\PDOException $e) {
            exit($e->getMessage());
        }
    }

    public function find($id)
    {
        $statement = "
            SELECT 
                *
            FROM
                suppliers
            WHERE supplier_id = ? AND status = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($id,1));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
    
    public function insert(Array $input)
    {
        $statement = "
            INSERT INTO suppliers 
                (fname, lname, phone_number)
            VALUES
                (:fname, :lname, :phone_number);
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':fname' => $input['fname'],
                ':lname'  => $input['lname'],
                ':phone_number'  => $input['phone_number']
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function update($supplier_id, Array $input)
    {
        $statement = "
            UPDATE 
                suppliers
            SET 
                fname = :fname,
                lname = :lname,
                phone_number = :phone_number
                WHERE supplier_id = :supplier_id;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':supplier_id' => $supplier_id,
                ':fname' => $input['fname'],
                ':lname'  => $input['lname'],
                ':phone_number'  => $input['phone_number']
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function delete($supplier_id)
    {
        $statement = "
            UPDATE 
                 suppliers
            SET 
                status = 0
            WHERE 
                supplier_id = :supplier_id;
        ";
        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array('supplier_id' => $supplier_id));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

}
?>