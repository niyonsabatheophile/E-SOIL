<?php
namespace Src\Models;

class ClientActionModel {
    private $db = null;

    public function __construct($db) {
        $this->db = $db;
    }

    public function findAll() {
        $statement = "
        SELECT *
            FROM 
        client_activities;
        ";
        try {
            $statement = $this->db->query($statement);
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;

        } catch (\PDOException $e) {
            exit($e->getMessage());
        }
    }

    public function find($id)
    {
        $statement = "
            SELECT 
                *
            FROM
                client_activities
            WHERE client_activity_id = ? AND status = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($id,1));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
    public function insert(Array $input)
    {
        $statement = "
            INSERT INTO client_activities 
                (client_id, token)
            VALUES
                (:client_id, :token);
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':client_id' => $input['client_id'],
                ':token'  => $input['token']
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function update(Array $input)
    {
        $statement = "
            UPDATE client_activities
            SET 
                status = :status
            WHERE client_activity_id = :client_activity_id;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':client_activity_id' => $input['client_activity_id'],
                ':status' => 0
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
}
?>