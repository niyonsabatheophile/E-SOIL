<?php
namespace Src\Models;

class ProductionModel {
    private $db = null;

    public function __construct($db) {
        $this->db = $db;
    }

    public function findAll() {
        $statement = "
        SELECT *
            FROM 
        productions WHERE status = 1;
        ";
        try {
            $statement = $this->db->query($statement);
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;

        } catch (\PDOException $e) {
            exit($e->getMessage());
        }
    }

    public function find($id)
    {
        $statement = "
            SELECT 
                *
            FROM
                productions
            WHERE production_id = ? AND status = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($id,1));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function findByProductTypeId($id)
    {
        $statement = "
            SELECT 
                *
            FROM
                productions
            WHERE product_type_id = ? AND status = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($id,1));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
    public function insert(Array $input)
    {
        $statement = "
            INSERT INTO productions 
                (operation_id, user_id, supplier_id, product_type_id, quantity)
            VALUES
                (:operation_id, :user_id, :supplier_id, :product_type_id, :quantity);
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':operation_id' => $input['operation_id'],
                ':user_id'  => $input['user_id'],
                ':supplier_id' => $input['supplier_id'],
                ':product_type_id' => $input['product_type_id'],
                ':quantity' => $input['quantity']
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function update($production_id, Array $input)
    {
        $statement = "
            UPDATE productions
            SET 
                operation_id = :operation_id,
                user_id = :user_id,
                supplier_id  = :supplier_id,
                product_type_id  = :product_type_id,
                quantity  = :quantity
            WHERE production_id = :production_id;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':production_id' => $production_id,
                ':user_id' => $input['user_id'],
                ':supplier_id'  => $input['supplier_id'],
                ':product_type_id'  => $input['product_type_id'],
                ':quantity'  => $input['quantity'],
                ':operation_id' => $input['operation_id']
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function delete($production_id)
    {
        $statement = "
            UPDATE 
                productions
            SET 
                status = 0
            WHERE 
                production_id = :production_id;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array('production_id' => $production_id));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

}
?>