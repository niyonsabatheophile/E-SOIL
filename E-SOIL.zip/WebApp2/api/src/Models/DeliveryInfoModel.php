<?php
namespace Src\Models;

class DeliveryInfoModel {
    private $db = null;

    public function __construct($db) {
        $this->db = $db;
    }

    public function findAll() {
        $statement = "
        SELECT *
            FROM 
        delivery_info;
        ";
        try {
            $statement = $this->db->query($statement);
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;

        } catch (\PDOException $e) {
            exit($e->getMessage());
        }
    }
    public function find($input)
    {
        $statement = "
                SELECT 
                    *
                FROM
                    delivery_info
                WHERE id = :id AND order_id = :order_id;
            ";
        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                "id" => $input['id'],
                "order_id" => $input['order_id']
            ));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
    public function findByOrderId($id)
    {
        $statement = "
            SELECT 
                *
            FROM
                delivery_info
            WHERE order_id = ?;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array($id));
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }
    public function insert(Array $input)
    {
        $statement = "
            INSERT INTO delivery_info 
                (order_id, country, province, city)
            VALUES
                (:order_id, :country, :province, :city);
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':order_id' => $input['order_id'],
                ':country'  => $input['country'],
                ':province'  => $input['province'],
                ':city'  => $input['city']
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function update(Array $input)
    {
        $statement = "
            UPDATE 
                delivery_info
            SET 
                country  = :country,
                province  = :province,
                city = :city
            WHERE 
                order_id = :order_id;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                ':order_id' => $input['order_id'],
                ':country'  => $input['country'],
                ':province'  => $input['province'],
                ':city'  => $input['city']
            ));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

    public function delete($input)
    {
        $statement = "
            DELETE FROM 
                delivery_info
            WHERE 
                order_id = :order_id AND id = :id;
        ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array("id" => $input['id'],"order_id" => $input['order_id']));
            return $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }    
    }

}
?>