<?php
$API_URL = 'https://localhost/api/';
$BASE = 'https://localhost/';
if (!isset($_SESSION['language'])) {
    $_SESSION['language'] = 'en';
}
$lang = $_SESSION['language'];

function language()
{
    if (isset($_SESSION['language'])) {
        if ($_SESSION['language'] == 'kiny') {
            return 'Kinyarwanda';
        } else {
            return 'English';
        }
    } else {
        return 'English';
    }
}

function title()
{
    $url = explode('/', $_SERVER['QUERY_STRING']);
    if ($url[0] == 'login') {
        echo 'Sign In | Ingabo Syndicate E-cassava market';
    } elseif ($url[0] == 'register') {
        echo 'Sign Up | Ingabo Syndicate E-cassava market';
    } elseif ($url[0] == 'cart') {
        echo 'Shopping cart | Ingabo Syndicate E-cassava market';
    } elseif ($url[0] == 'profile') {
        echo 'Ingabo Syndicate E-cassava market';
    } elseif ($url[0] == 'forgot') {
        echo 'Password recovery | Ingabo Syndicate E-cassava market';
    } elseif ($url[0] == 'products') {
        echo 'Explore cassava products | Ingabo Syndicate E-cassava market';
    } elseif ($url[0] == 'details') {
        echo 'Ingabo Syndicate E-cassava market';
    } else {
        echo 'Ingabo Syndicate E-cassava market';
    }
}
?>
