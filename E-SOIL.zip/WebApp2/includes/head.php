<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="icon" href="images/logo.png" type="image/png"> -->

    <title><?php echo 'Real time soil fertility analyser using IoT'; ?></title>
    <!--Let browser know website is optimized for mobile-->
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="title" content="<?php echo 'Real time soil fertility analyser using IoT'; ?>">
    <!-- <meta property="og:image" content="<?php echo $BASE; ?>images/logo.png" /> -->

     <!-- Compiled and minified CSS -->
     <link rel="stylesheet" href="<?php base(); ?>materialize/css/materialize.min.css">
     <!-- FOnt awesomes -->
     <link href="<?php base(); ?>css/fontawesome/css/all.css" rel="stylesheet">
     <!-- Google fonts -->
     <link href="https://fonts.googleapis.com/css2?family=Comfortaa:wght@600&display=swap" rel="stylesheet">
    
     <!-- Leaflet -->
     <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css"
   integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A=="
   crossorigin=""/>

   <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.22/datatables.min.css"/>
 
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
     <link rel="stylesheet" href="<?php base(); ?>css/css.css">
     <style>
         * { font-family: 'Comfortaa', cursive; }
         @media only screen and (max-width: 992px) {
            nav .brand-logo {
                left: 0;
                -webkit-transform: translateX(-50%);
                transform: translateX(-50%);
            }
        }
     </style>
</head>