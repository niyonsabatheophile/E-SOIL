<header>
	<nav class="light-green darken-1">
		<div class="nav-wrapper">
			<div class="row">
				<div class="col s12">
					<a href="#" data-target="sidenav-1" class="left sidenav-trigger hide-on-medium-and-up"><i class="material-icons">menu</i></a>
					<a href="#" class="brand-logo center"><img src="https://svgshare.com/i/Bza.svg" alt="Sage Leaf icon"></a>
				</div>
				<div class="row">
					<div class="col xl2 l2 m12">

					</div>
					<div class="col xl10 l10 m12">
						<center><h5>Real time soil fertility analyser using IoT</h5></center>
					</div>
				</div>
			</div>
		</div>
	</nav>
</header>

<ul id="sidenav-1" class="sidenav sidenav-fixed">
	<li><a href="<?php echo $BASE; ?>"><i class="fas fa-home"></i> Dashboard</a></li>
	<li><a href="<?php echo $BASE; ?>chart"><i class="fas fa-book"></i> Charts</a></li>
	<li><a href="<?php echo $BASE; ?>map"><i class="fas fa-book"></i> Map</a></li>
	<li><a href="<?php echo $BASE; ?>report"><i class="fas fa-book"></i> Report</a></li>
	<li><a href="<?php echo $BASE; ?>logout"><i class="fas fa-user"></i> Logout</a></li>
</ul>